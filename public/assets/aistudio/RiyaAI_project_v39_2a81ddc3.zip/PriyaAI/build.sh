#!/data/data/com.termux/files/usr/bin/bash
# APK banao: bash build.sh   (age check.sh nijei chole)
cd "$(dirname "$0")"
bash ./check.sh || exit 1
V=$(gradle --version 2>/dev/null | awk '/^Gradle/{print $2}')
case "$V" in 9.*) echo "ℹ Gradle $V (AGP 8.5.2-এর জন্য নতুন, তবে আগের বিল্ডগুলো এতে সফল হয়েছে)";; esac
echo "[৪] বিল্ড শুরু… (সময় লাগবে, স্ক্রিন লক করবেন না)"
gradle assembleDebug 2>&1 | tee build.log | grep -E '^(e:|FAILURE|BUILD|> Task :app:compileDebugKotlin)'
if ! grep -q "BUILD SUCCESSFUL" build.log; then
  echo; echo "✗ বিল্ড ব্যর্থ। আপনার আগের ইনস্টল করা অ্যাপ ও APK অক্ষত আছে, কিছু বদলায়নি।"
  if grep -q '^e:' build.log; then
    echo "  কোডের ত্রুটি (কপি করে পাঠান):"; grep '^e:' build.log | sed 's#file:///storage/emulated/0/Download/PriyaAI/##' | head -15
  else
    echo "  কোডের ত্রুটি নেই, অন্য কারণে থেমেছে। লগের শেষ অংশ (কপি করে পাঠান):"; echo "-----"; tail -n 30 build.log; echo "-----"
  fi
  echo "  পুরো লগ: $(pwd)/build.log"
  exit 1
fi
APK=app/build/outputs/apk/debug/app-debug.apk
[ -f "$APK" ] || { echo "✗ APK ফাইল তৈরি হয়নি"; exit 1; }
SIZE=$(stat -c %s "$APK")
[ "$SIZE" -lt 1000000 ] && { echo "✗ APK সন্দেহজনক ছোট ($SIZE বাইট), ইনস্টল করবেন না"; exit 1; }
if command -v aapt2 >/dev/null; then
  INFO=$(aapt2 dump badging "$APK" 2>/dev/null | head -1)
  echo "$INFO" | grep -q "name='com.priya.ai'" && echo "✓ প্যাকেজ ঠিক আছে (com.priya.ai)" || echo "⚠ প্যাকেজ নাম যাচাই করা গেল না"
fi
if [ -d /sdcard/Download ]; then
  OUT="/sdcard/Download/RiyaAI_$(date +%m%d_%H%M).apk"
  cp "$APK" "$OUT" && echo "✓ APK তৈরি: $OUT ($((SIZE/1048576)) MB)"
  echo "  (পুরনো APK মোছা হয়নি; নতুনটা আলাদা নামে)"
  command -v termux-open >/dev/null && termux-open "$OUT" 2>/dev/null && echo "→ ইনস্টলার খুলছে, 'Install/Update' চাপুন"
  echo "  না খুললে: ফাইল ম্যানেজার > Downloads > $(basename $OUT) ট্যাপ করুন"
fi
