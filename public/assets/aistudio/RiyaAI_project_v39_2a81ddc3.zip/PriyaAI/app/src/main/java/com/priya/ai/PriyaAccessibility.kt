package com.priya.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class PriyaAccessibility : AccessibilityService() {
    companion object {
        @Volatile var instance: PriyaAccessibility? = null
        @Volatile var currentScreenSummary: String = ""
        @Volatile var currentApp: String = ""
    }

    private var lastScan = 0L

    override fun onServiceConnected() { instance = this; PriyaState.resume.value++ }
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try {
            if (e == null) return
            val pkg = e.packageName?.toString() ?: ""
            if (pkg.isNotEmpty() && !pkg.contains("com.priya.ai")) {
                currentApp = pkg
                val now = System.currentTimeMillis()
                if (now - lastScan >= 1200) {
                    lastScan = now
                    updateCurrentScreenContext()
                }
            }
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {}

    private fun updateCurrentScreenContext() {
        try {
            val sb = StringBuilder()
            fun walk(n: AccessibilityNodeInfo?, d: Int) {
                if (n == null || sb.length > 500) return
                val t = n.text?.toString() ?: n.contentDescription?.toString()
                if (!t.isNullOrBlank()) sb.append(t.take(60)).append(", ")
                for (i in 0 until minOf(n.childCount, 8)) walk(n.getChild(i), d + 1)
            }
            walk(rootInActiveWindow, 0)
            if (sb.isNotEmpty()) {
                currentScreenSummary = "বর্তমান অ্যাপ: $currentApp | স্ক্রিন দৃশ্য: ${sb.toString().take(300)}"
            }
        } catch (_: Exception) {}
    }

    // স্ক্রিন পড়া: উপর থেকে নিচে, বাঁ থেকে ডানে সাজানো। বাটন, লেখার বক্স, সুইচ আলাদা করে চিহ্নিত।
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "স্ক্রিন পাওয়া যায়নি"
        val rows = mutableListOf<Triple<Int, Int, String>>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || rows.size > 150) return
            val raw = n.text?.toString()?.trim()
            val desc = n.contentDescription?.toString()?.trim()
            val t = if (!raw.isNullOrEmpty()) raw else desc
            val hint = if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString()?.trim() else null
            val r = Rect(); n.getBoundsInScreen(r)
            val tag = when {
                n.isEditable -> " [লেখার বক্স]"
                n.isCheckable -> if (n.isChecked) " [সুইচ: চালু]" else " [সুইচ: বন্ধ]"
                n.isClickable -> " [বাটন]"
                else -> ""
            }
            val label: String? = when {
                !t.isNullOrEmpty() -> t.take(120)
                n.isEditable -> if (!hint.isNullOrEmpty()) "(খালি লেখার বক্স, হিন্ট: ${hint.take(40)})" else "(খালি লেখার বক্স)"
                else -> null
            }
            if (label != null) rows.add(Triple(r.top, r.left, label + tag))
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        val lines = rows.sortedWith(compareBy<Triple<Int, Int, String>>({ it.first / 20 }, { it.second }))
            .map { it.third }.distinct()
        if (lines.isEmpty()) return "স্ক্রিনে পড়ার মতো কিছু পাওয়া যায়নি"
        return "অ্যাপ: ${root.packageName ?: ""}\n" + lines.joinToString("\n").take(4000)
    }

    // চ্যাট বা লেখার বক্সে মেসেজ লেখা ও সেন্ড (WhatsApp, imo, Messenger)
    fun sendMessageInCurrentChat(msg: String): String {
        val root = rootInActiveWindow ?: return "স্ক্রিন পাওয়া যায়নি"
        var box = findEditableNode(root)
        if (box == null) {
            // বক্স ফাঁকা থাকলে অনেক সময় শুধু হিন্ট দেখায়; সেটিতে ট্যাপ করে ফোকাস দিই
            findNodeByKeys(root, listOf("message", "মেসেজ", "type a message", "lekho"))?.let { clickNode(it); Thread.sleep(400) }
            box = findEditableNode(rootInActiveWindow)
        }
        if (box == null) return "মেসেজ লেখার বক্স খুঁজে পাইনি বস"
        box.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, msg) }
        if (!box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return "মেসেজ লেখা যায়নি বস"
        Thread.sleep(400)
        val send = findSendNode(rootInActiveWindow, box)
        if (send != null && clickNode(send)) {
            Thread.sleep(300)
            return "মেসেজ পাঠিয়ে দিয়েছি বস!"
        }
        return "মেসেজ লেখা হয়েছে কিন্তু সেন্ড বাটন খুঁজে পাইনি বস, একবার দেখে নাও"
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        return (c ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findNodeByKeys(n: AccessibilityNodeInfo?, keys: List<String>): AccessibilityNodeInfo? {
        if (n == null) return null
        val t = (n.text?.toString() ?: "").lowercase()
        val d = (n.contentDescription?.toString() ?: "").lowercase()
        val h = (if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString() ?: "" else "").lowercase()
        if (keys.any { k -> t.contains(k) || d.contains(k) || h.contains(k) }) return n
        for (i in 0 until n.childCount) findNodeByKeys(n.getChild(i), keys)?.let { return it }
        return null
    }

    private fun collectClickable(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        if (n.isClickable) out.add(n)
        for (i in 0 until n.childCount) collectClickable(n.getChild(i), out)
    }

    // সেন্ড বাটন: আগে নাম/বর্ণনায় "send/সেন্ড/পাঠান" খোঁজে, না পেলে লেখার বক্সের ডান পাশের সবচেয়ে ডানের বাটন
    private fun findSendNode(root: AccessibilityNodeInfo?, box: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val all = mutableListOf<AccessibilityNodeInfo>()
        collectClickable(root, all)
        val words = listOf("send", "সেন্ড", "পাঠান")
        all.firstOrNull { n ->
            val s = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()
            words.any { s.contains(it) }
        }?.let { return it }
        val bb = Rect(); box.getBoundsInScreen(bb)
        val midY = bb.centerY()
        return all.filter { n ->
            val r = Rect(); n.getBoundsInScreen(r)
            r.width() > 0 && r.left >= bb.right - 10 && Math.abs(r.centerY() - midY) < bb.height() + 40
        }.maxByOrNull { n -> val r = Rect(); n.getBoundsInScreen(r); r.right }
    }

    fun findEditableNode(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val r = findEditableNode(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    fun hasText(t: String): Boolean {
        val q = t.trim().lowercase()
        if (q.isEmpty()) return false
        fun f(n: AccessibilityNodeInfo?): Boolean {
            if (n == null) return false
            if ((n.text?.toString()?.lowercase() ?: "").contains(q) || (n.contentDescription?.toString()?.lowercase() ?: "").contains(q)) return true
            for (i in 0 until n.childCount) if (f(n.getChild(i))) return true
            return false
        }
        return f(rootInActiveWindow)
    }

    /** স্ক্রিনে না পেলে নিচে স্ক্রল করে খোঁজে (সর্বোচ্চ [maxScrolls] বার) */
    fun scrollUntilFound(t: String, maxScrolls: Int = 4): Boolean {
        if (hasText(t)) return true
        repeat(maxScrolls) {
            if (!scroll("down").contains("সম্পন্ন")) return false
            Thread.sleep(500)
            if (hasText(t)) return true
        }
        return false
    }

    fun clickText(t: String, isContact: Boolean = false): String {
        val root = rootInActiveWindow ?: return "স্ক্রিন পাওয়া যায়নি"
        val query = t.trim().lowercase()

        // ১. আংশিক বা প্রথম নামের সাথে ম্যাচিং নোড খোঁজা
        var matchedNode: AccessibilityNodeInfo? = null
        fun findMatch(n: AccessibilityNodeInfo?) {
            if (n == null || matchedNode != null) return
            val txt = n.text?.toString()?.lowercase() ?: ""
            val desc = n.contentDescription?.toString()?.lowercase() ?: ""
            // কন্টাক্ট মোডে (WhatsApp) শুধু নামের লেখায় ক্লিক, প্রোফাইল ছবিতে নয়
            val hit = if (isContact) txt.contains(query) else (txt.contains(query) || desc.contains(query))
            if (hit) {
                matchedNode = n
                return
            }
            for (i in 0 until n.childCount) findMatch(n.getChild(i))
        }
        findMatch(root)

        if (matchedNode != null) {
            var c: AccessibilityNodeInfo? = matchedNode
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return "'$t' ক্লিক করা হয়েছে"
            }
        }

        // ২. না পেলে সার্চ আইকন খুঁজে লিখে সার্চ দেওয়া
        val searchNode = findSearchNode(root)
        if (searchNode != null) {
            searchNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Thread.sleep(300)
            val focusNode = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focusNode != null) {
                val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
                if (!focusNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return "'$t' সার্চবারে লেখা গেল না"
                Thread.sleep(150)
                var submitted = false
                if (Build.VERSION.SDK_INT >= 30) {
                    focusNode.refresh()
                    submitted = focusNode.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                }
                if (!submitted) submitted = findSubmitNode(rootInActiveWindow)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                return if (submitted) "'$t' সরাসরি পাওয়া যায়নি, তাই সার্চবারে লিখে সার্চ দেওয়া হয়েছে"
                else "'$t' সার্চবারে লিখেছি, কিন্তু সার্চ বাটন চাপতে পারিনি; কিবোর্ডের সার্চ/এন্টার চাপতে হবে"
            }
        }

        return "'$t' খুঁজে পাওয়া যায়নি"
    }

    private fun findSubmitNode(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = (n.contentDescription?.toString() ?: "").lowercase()
        val t = (n.text?.toString() ?: "").lowercase()
        if (n.isClickable && (d == "search" || d == "go" || d == "সার্চ" || t == "search" || t == "go" || t == "সার্চ" ||
                d.contains("submit") || d.contains("search button"))) return n
        for (i in 0 until n.childCount) findSubmitNode(n.getChild(i))?.let { return it }
        return null
    }

    private fun findSearchNode(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val desc = (n.contentDescription?.toString() ?: "").lowercase()
        val text = (n.text?.toString() ?: "").lowercase()
        if (n.isClickable && (desc.contains("search") || desc.contains("খুঁজুন") || desc.contains("সার্চ") || text.contains("search") || text.contains("সার্চ"))) {
            return n
        }
        for (i in 0 until n.childCount) {
            val res = findSearchNode(n.getChild(i))
            if (res != null) return res
        }
        return null
    }

    /** চালু স্ক্রিনের সুইচ (Wi-Fi/Bluetooth) খুঁজে অন/অফ করে। ফল যাচাই করে। */
    fun setSwitch(enable: Boolean, labels: List<String>): String {
        fun all(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
            if (n == null) return
            if (n.isCheckable) out.add(n)
            for (i in 0 until n.childCount) all(n.getChild(i), out)
        }
        fun label(n: AccessibilityNodeInfo): String {
            val sb = StringBuilder()
            var p: AccessibilityNodeInfo? = n
            var depth = 0
            while (p != null && depth < 3) {
                sb.append(p.text ?: "").append(' ').append(p.contentDescription ?: "").append(' ')
                for (i in 0 until p.childCount) { val c = p.getChild(i); sb.append(c?.text ?: "").append(' ') }
                p = p.parent; depth++
            }
            return sb.toString().lowercase()
        }
        repeat(4) {
            val list = mutableListOf<AccessibilityNodeInfo>()
            all(rootInActiveWindow, list)
            if (list.isNotEmpty()) {
                val sw = list.firstOrNull { n -> labels.any { label(n).contains(it) } } ?: list.first()
                if (sw.isChecked == enable) return "ALREADY"
                var c: AccessibilityNodeInfo? = sw
                while (c != null && !c.isClickable) c = c.parent
                (c ?: sw).performAction(AccessibilityNodeInfo.ACTION_CLICK)
                Thread.sleep(400)
                sw.refresh()
                return if (sw.isChecked == enable) "OK" else "CLICKED"
            }
            Thread.sleep(250)
        }
        return "NOTFOUND"
    }

    fun typeText(t: String): String {
        val root = rootInActiveWindow ?: return "স্ক্রিন নেই"
        val box = findEditableNode(root) ?: return "কোনো লেখার বক্স পাওয়া যায়নি"
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return if (box.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "টাইপ সম্পন্ন" else "টাইপ করা যায়নি"
    }

    fun global(a: String): String {
        val act = when (a) {
            "home" -> GLOBAL_ACTION_HOME; "back" -> GLOBAL_ACTION_BACK
            "recents" -> GLOBAL_ACTION_RECENTS; "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "lock" -> GLOBAL_ACTION_LOCK_SCREEN; else -> return "অজানা কমান্ড"
        }
        return if (performGlobalAction(act)) "সম্পন্ন" else "ব্যর্থ"
    }

    fun scroll(dir: String): String {
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        val s = find(rootInActiveWindow) ?: return "স্ক্রল করার জায়গা পাওয়া যায়নি"
        val a = if (dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        return if (s.performAction(a)) "স্ক্রল সম্পন্ন" else "স্ক্রল ব্যর্থ"
    }

    fun clickFirstVideo(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != "com.google.android.youtube") return false
        val dur = Regex("\\d+\\s*(minutes?|seconds?|hours?|মিনিট|সেকেন্ড|ঘণ্টা)")
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            val d = n.contentDescription?.toString()?.lowercase()
            if (n.isClickable && d != null && !d.contains("sponsored") && !d.contains("বিজ্ঞাপন") &&
                (d.contains("play video") || d.contains("ভিডিও চালান") || dur.containsMatchIn(d))) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        return find(root)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    private val shotExec = Executors.newSingleThreadExecutor()

    fun screenshotJpeg(cb: (ByteArray?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExec, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        r.hardwareBuffer.close()
                        if (bmp == null) { cb(null); return }
                        val sc = 720f / maxOf(bmp.width, bmp.height)
                        val sm = if (sc < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true) else bmp
                        val o = ByteArrayOutputStream()
                        sm.compress(Bitmap.CompressFormat.JPEG, 55, o)
                        cb(o.toByteArray())
                    } catch (e: Exception) { cb(null) }
                }
                override fun onFailure(errorCode: Int) { cb(null) }
            })
        } catch (e: Exception) { cb(null) }
    }

    /** নির্দিষ্ট স্ক্রিন-বিন্দুতে ট্যাপ (সেন্ড বাটন ক্লিকযোগ্য নোড না হলে) */
    fun tapAt(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(), null, null)
    }

    fun tapFallback() {
        val m = resources.displayMetrics
        val path = Path().apply { moveTo(m.widthPixels * 0.5f, m.heightPixels * 0.38f) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build(), null, null)
    }
}
