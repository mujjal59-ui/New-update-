package com.priya.ai

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo

// মেসেজ পাঠানোর একক কাজ: সঠিক অ্যাপ খোলা -> নামে চ্যাট খোলা -> নাম যাচাই -> লেখা -> সেন্ড বাটনে ক্লিক -> পাঠানো যাচাই।
// এটি পুরোটা ব্যাকগ্রাউন্ডে চলে; বসকে কোনো ধাপ জিজ্ঞেস করে না।
object MessageAgent {

    class AppSpec(val key: String, val pkg: String, val label: String, val aliases: List<String>, val isAi: Boolean)

    private val APPS = listOf(
        AppSpec("whatsapp", "com.whatsapp", "WhatsApp",
            listOf("whatsapp", "হোয়াটসঅ্যাপ", "হোয়াটস্যাপ", "ওয়াটসঅ্যাপ"), false),
        AppSpec("imo", "com.imo.android.imoim", "imo",
            listOf("imo", "ইমো", "ইমু", "আইমো"), false),
        AppSpec("messenger", "com.facebook.orca", "Messenger",
            listOf("messenger", "মেসেঞ্জার", "মেসেনজার", "ম্যাসেঞ্জার"), false),
        AppSpec("gemini", "com.google.android.apps.bard", "Gemini",
            listOf("gemini", "জেমিনি"), true),
        AppSpec("chatgpt", "com.openai.chatgpt", "ChatGPT",
            listOf("chatgpt", "chat gpt", "chat got", "চ্যাটজিপিটি"), true)
    )

    fun find(name: String): AppSpec? {
        val n = name.lowercase().trim()
        if (n.isEmpty()) return null
        return APPS.firstOrNull { a -> a.aliases.any { al -> n == al.lowercase() || n.contains(al.lowercase()) } }
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[\\s._\\-]+"), "")

    private fun rootPkg(acc: PriyaAccessibility) = acc.rootInActiveWindow?.packageName?.toString() ?: ""

    private fun screenH(acc: PriyaAccessibility): Int {
        val r = Rect()
        acc.rootInActiveWindow?.getBoundsInScreen(r)
        return if (r.height() > 0) r.height() else 2400
    }

    private fun bounds(n: AccessibilityNodeInfo): Rect {
        val r = Rect()
        n.getBoundsInScreen(r)
        return r
    }

    private fun label(n: AccessibilityNodeInfo): String =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).trim()

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out)
    }

    private fun all(acc: PriyaAccessibility): MutableList<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        collect(acc.rootInActiveWindow, out)
        return out
    }

    private fun clickableAncestor(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var c: AccessibilityNodeInfo? = n
        var depth = 0
        while (c != null && !c.isClickable && depth < 6) {
            c = c.parent
            depth++
        }
        return if (c != null && c.isClickable) c else null
    }

    private fun setText(n: AccessibilityNodeInfo, t: String): Boolean {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    // প্যাকেজ নাম না মিললে লঞ্চার থেকে অ্যাপের নাম দিয়ে খোঁজা
    private fun launchByLabel(ctx: Context, app: AppSpec): Intent? {
        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(li, 0).firstOrNull { ri ->
            val l = ri.loadLabel(pm).toString().lowercase()
            l == app.label.lowercase() || app.aliases.any { l == it.lowercase() }
        } ?: return null
        return Intent(li).setClassName(hit.activityInfo.packageName, hit.activityInfo.name)
    }

    // ১. হোম স্ক্রিনে গিয়ে নির্দিষ্ট প্যাকেজ খোলা, এবং সেটি সামনে এসেছে কি না যাচাই
    fun openApp(ctx: Context, acc: PriyaAccessibility, app: AppSpec): Boolean {
        acc.global("home")
        Thread.sleep(700)
        val intent = ctx.packageManager.getLaunchIntentForPackage(app.pkg)
            ?: launchByLabel(ctx, app)
            ?: return false
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val deadline = System.currentTimeMillis() + 10000
        while (System.currentTimeMillis() < deadline) {
            Thread.sleep(300)
            if (rootPkg(acc) == app.pkg || PriyaAccessibility.currentApp == app.pkg) {
                Thread.sleep(900)
                return true
            }
        }
        return false
    }

    // ২. চ্যাট তালিকায় নামের সারিতে ক্লিক; না পেলে অ্যাপের সার্চে খোঁজা ও স্ক্রল
    fun openChat(acc: PriyaAccessibility, contact: String): Boolean {
        val target = norm(contact)
        if (target.isEmpty()) return false
        for (attempt in 0 until 4) {
            if (clickRowFor(acc, target)) return true
            if (attempt == 0) searchInApp(acc, contact)
            acc.scroll("down")
            Thread.sleep(600)
        }
        return false
    }

    private fun clickRowFor(acc: PriyaAccessibility, target: String): Boolean {
        val h = screenH(acc)
        val candidates = all(acc).filter { n ->
            val t = norm(n.text?.toString() ?: n.contentDescription?.toString() ?: "")
            t.isNotEmpty() && (t == target || (target.length >= 3 && t.contains(target))) && bounds(n).top > h * 0.12
        }.sortedByDescending { n -> if (norm(n.text?.toString() ?: "") == target) 1 else 0 }
        for (n in candidates) {
            val row = clickableAncestor(n) ?: continue
            val r = bounds(row)
            if (row.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun searchInApp(acc: PriyaAccessibility, query: String) {
        val s = all(acc).firstOrNull { n ->
            val l = label(n).lowercase()
            (l.contains("search") || l.contains("সার্চ") || l.contains("খুঁজ")) && clickableAncestor(n) != null
        } ?: return
        clickableAncestor(s)?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        Thread.sleep(900)
        val box = all(acc).firstOrNull { it.isEditable } ?: return
        setText(box, query)
        Thread.sleep(1200)
    }

    // ৩. খোলা চ্যাটের হেডারে (উপরের অংশে) নাম আছে কি না যাচাই
    fun headerHas(acc: PriyaAccessibility, contact: String): Boolean {
        val target = norm(contact)
        val h = screenH(acc)
        return all(acc).any { n -> bounds(n).top < h * 0.2 && norm(label(n)).contains(target) }
    }

    private fun isInput(n: AccessibilityNodeInfo): Boolean =
        n.isEditable || (n.className?.toString()?.contains("EditText") == true)

    private fun bottomEditable(acc: PriyaAccessibility, h: Int): AccessibilityNodeInfo? =
        all(acc).filter { isInput(it) && bounds(it).top > h * 0.5 }.maxByOrNull { bounds(it).top }

    // ৪. লেখার বক্স খুঁজে লেখা, না বসলে ক্লিপবোর্ড পেস্ট
    private fun writeMessage(ctx: Context, acc: PriyaAccessibility, msg: String, h: Int): Boolean {
        var box = bottomEditable(acc, h)
        if (box == null) {
            all(acc).firstOrNull { n ->
                val s = label(n).lowercase()
                (s.contains("message") || s.contains("type") || s.contains("মেসেজ") || s.contains("লিখ")) && bounds(n).top > h * 0.6
            }?.let { clickableAncestor(it)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: it.performAction(AccessibilityNodeInfo.ACTION_CLICK) }
            Thread.sleep(500)
            box = bottomEditable(acc, h)
        }
        if (box == null) return false
        setText(box, msg)
        Thread.sleep(400)
        val now = bottomEditable(acc, h)?.text?.toString()?.trim() ?: ""
        if (!now.contains(msg.take(12))) {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("rea", msg))
            bottomEditable(acc, h)?.let {
                it.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                it.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            }
            Thread.sleep(500)
        }
        return (bottomEditable(acc, h)?.text?.toString() ?: "").isNotEmpty()
    }

    // সেন্ড বাটন: লেখার বক্সের ডান দিকে, একই সারিতে, সবচেয়ে ডানের বাটন; "send/সেন্ড/পাঠান" লেখা থাকলে আগে
    private fun findSend(acc: PriyaAccessibility, box: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val bb = bounds(box)
        val bad = listOf("attach", "emoji", "sticker", "camera", "mic", "voice", "plus", "add", "gif", "gallery", "photo", "image",
            "ইমোজি", "ক্যামেরা", "মাইক", "ছবি", "সংযুক্ত", "ফাইল")
        val rows = mutableListOf<Pair<AccessibilityNodeInfo, Rect>>()
        for (n in all(acc)) {
            val row = clickableAncestor(n) ?: continue
            if (row === box) continue
            val r = bounds(row)
            if (r.width() <= 0) continue
            if (r.centerY() < bb.top - 200 || r.centerY() > bb.bottom + 200) continue
            if (r.left < bb.centerX()) continue
            val l = (label(row) + " " + label(n)).lowercase()
            if (bad.any { l.contains(it) }) continue
            rows.add(row to r)
        }
        val words = listOf("send", "সেন্ড", "পাঠান")
        rows.firstOrNull { (row, _) -> words.any { label(row).lowercase().contains(it) } }?.let { return it.first }
        return rows.maxByOrNull { it.second.right }?.first
    }

    // সেন্ড: বাটন আসতে সময় লাগে, তাই কিছুক্ষণ খুঁজি; ক্লিক না হলে স্ক্রিন-বিন্দুতে ট্যাপ;
    // পাঠানো নিশ্চিত হলে তবেই "পাঠানো হয়েছে" বলি (লেখার বক্স খালি বা মেসেজ চ্যাটে দেখা গেলে)
    private fun sendTyped(acc: PriyaAccessibility, h: Int, msg: String): String {
        val box0 = bottomEditable(acc, h) ?: return "লেখার বক্স হারিয়ে গেছে"
        val boxTop = bounds(box0).top
        var found: AccessibilityNodeInfo? = null
        for (i in 0 until 8) {
            found = findSend(acc, box0)
            if (found != null) break
            Thread.sleep(400)
        }
        val sendNode = found ?: return "সেন্ড বাটন খুঁজে পাইনি"
        val sr = bounds(sendNode)
        var clicked = (clickableAncestor(sendNode) ?: sendNode).performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (!clicked) clicked = acc.tapAt(sr.exactCenterX(), sr.exactCenterY())
        if (!clicked) return "সেন্ড বাটনে ক্লিক হয়নি"

        val probe = msg.trim().take(20)
        for (i in 0 until 8) {
            Thread.sleep(400)
            val left = bottomEditable(acc, h)?.text?.toString()?.trim() ?: ""
            if (left.isEmpty()) return "পাঠানো হয়েছে"
            if (probe.isNotEmpty() && all(acc).any { n ->
                    val t = n.text?.toString() ?: ""
                    val top = bounds(n).top
                    t.contains(probe) && top > h * 0.15 && top < boxTop
                }) return "পাঠানো হয়েছে"
        }
        // আরেকবার সেন্ড বাটনে ট্যাপ
        findSend(acc, box0)?.let { s2 ->
            val r2 = bounds(s2)
            acc.tapAt(r2.exactCenterX(), r2.exactCenterY())
        }
        Thread.sleep(1200)
        val left2 = bottomEditable(acc, h)?.text?.toString()?.trim() ?: ""
        return if (left2.isEmpty()) "পাঠানো হয়েছে" else "লেখা বক্সে আছে, পাঠানো যায়নি"
    }

    // মূল এন্ট্রি: অ্যাপ, নাম, মেসেজ
    fun run(ctx: Context, acc: PriyaAccessibility, appName: String, contact: String, msg: String): String {
        val app = find(appName) ?: return "এই অ্যাপটি চিনতে পারিনি: $appName"
        if (msg.isBlank()) return "কী লিখবো বলোনি বস"
        if (!app.isAi && contact.isBlank()) return "কাকে মেসেজ পাঠাবো বলোনি বস"
        if (!openApp(ctx, acc, app)) return "${app.label} খুলতে পারিনি বস"
        if (!app.isAi) {
            if (!openChat(acc, contact)) return "${app.label}-এ '$contact' নামের চ্যাট পাইনি বস"
            val until = System.currentTimeMillis() + 5000
            while (System.currentTimeMillis() < until && bottomEditable(acc, screenH(acc)) == null) Thread.sleep(300)
            Thread.sleep(400)
            if (!headerHas(acc, contact)) return "চ্যাট খুলেছি কিন্তু হেডারে '$contact' মিলছে না, তাই পাঠাইনি বস"
        }
        val h = screenH(acc)
        if (!writeMessage(ctx, acc, msg, h)) return "${app.label}-এ লেখার বক্স খুঁজে পাইনি বস"
        val res = sendTyped(acc, h, msg)
        return "${app.label}${if (app.isAi) "" else " / $contact"}: $res"
    }
}
