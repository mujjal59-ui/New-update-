package com.priya.ai

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class PriyaService : Service() {
    private var live: GeminiLive? = null
    private var wl: android.os.PowerManager.WakeLock? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("priya", "Priya", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, PriyaService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "priya").setContentTitle("Priya sun rahi hai")
            .setContentText("Always listening mode ON").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open).addAction(0, "Stop", stop).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        try { Keep.ensureAccessibility(this) } catch (_: Exception) {}
        if (wl == null) {
            try {
                wl = (getSystemService(POWER_SERVICE) as android.os.PowerManager)
                    .newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "priya:live").apply { setReferenceCounted(false); acquire() }
            } catch (_: Exception) {}
        }
        if (live == null) {
            live = GeminiLive(applicationContext).also { PriyaState.live = it; it.start() }
            PriyaState.running.value = true
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { wl?.release() } catch (_: Exception) {}; wl = null
        live?.stop(); live = null; PriyaState.live = null
        PriyaState.running.value = false; PriyaState.status.value = "Tap to speak"
        super.onDestroy()
    }
}
