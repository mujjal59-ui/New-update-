package com.priya.ai

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.*

object PriyaState {
    val running = MutableStateFlow(false)
    val resume = MutableStateFlow(0)
    val status = MutableStateFlow("Tap to speak")
    val log = MutableStateFlow<List<String>>(emptyList())
    @Volatile var live: GeminiLive? = null
    @Volatile var cameraOn: Boolean = false
    fun addLog(s: String) { log.value = (log.value + s).takeLast(60) }
}

object Store {
    const val CAP = 30L * 1024 * 1024 // 30 MB memory cap
    private fun p(c: Context) = c.getSharedPreferences("priya", Context.MODE_PRIVATE)
    fun apiKey(c: Context) = p(c).getString("key", "")!!
    fun setApiKey(c: Context, v: String) = p(c).edit().putString("key", v.trim()).apply()
    
    // লাইভ API-এর জন্য মডেল (gemini-2.0-flash-exp ও gemini-2.0-flash-live-001 গুগল ৯ ডিসেম্বর ২০২৫-এ বন্ধ করে দিয়েছে)
    fun model(c: Context): String {
        val m = p(c).getString("model", "gemini-3.1-flash-live-preview")!!
        return if (m.contains("2.0-flash")) "gemini-3.1-flash-live-preview" else m
    }
    fun setModel(c: Context, v: String) = p(c).edit().putString("model", v.trim()).apply()
    
    fun voice(c: Context) = p(c).getString("voice", "Leda")!!
    fun setVoice(c: Context, v: String) = p(c).edit().putString("voice", v.trim().ifBlank { "Leda" }).apply()
    
    // Screen Watch সবসময় চালু (বাধ্যতামূলক)। আগের টগল বাদ।
    fun screenWatch(c: Context) = true
    fun setScreenWatch(c: Context, v: Boolean) { }

    fun autoReplyWhatsApp(c: Context) = p(c).getBoolean("arWa", true)
    fun setAutoReplyWhatsApp(c: Context, v: Boolean) = p(c).edit().putBoolean("arWa", v).apply()
    fun autoReplyImo(c: Context) = p(c).getBoolean("arImo", true)
    fun setAutoReplyImo(c: Context, v: Boolean) = p(c).edit().putBoolean("arImo", v).apply()
    fun autoReplyMessenger(c: Context) = p(c).getBoolean("arMsg", true)
    fun setAutoReplyMessenger(c: Context, v: Boolean) = p(c).edit().putBoolean("arMsg", v).apply()
    fun design(c: Context) = p(c).getInt("design", 0)
    fun setDesign(c: Context, v: Int) = p(c).edit().putInt("design", v).apply()
    fun always(c: Context) = p(c).getBoolean("always", false)
    fun setAlways(c: Context, v: Boolean) = p(c).edit().putBoolean("always", v).apply()

    private fun f(c: Context) = File(c.filesDir, "memory.txt")
    fun size(c: Context) = f(c).let { if (it.exists()) it.length() else 0L }
    fun clear(c: Context) { f(c).delete() }

    @Synchronized
    fun remember(c: Context, line: String) {
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val file = f(c)
        file.appendText("[$ts] ${line.replace("\n", " ")}\n")
        if (file.length() > CAP) trim(file)
    }

    private fun trim(file: File) {
        val keep = (CAP * 0.8).toLong()
        val rest = RandomAccessFile(file, "r").use { r ->
            r.seek(file.length() - keep); r.readLine()
            ByteArray((file.length() - r.filePointer).toInt()).also { r.readFully(it) }
        }
        file.writeBytes(rest)
    }

    fun recent(c: Context, max: Int = 20000): String {
        val file = f(c); if (!file.exists()) return ""
        return RandomAccessFile(file, "r").use { r ->
            val start = maxOf(0L, r.length() - max)
            r.seek(start)
            ByteArray((r.length() - start).toInt()).also { r.readFully(it) }.toString(Charsets.UTF_8)
        }
    }
}
