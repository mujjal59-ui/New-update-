package com.priya.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.media.AudioManager
import android.os.BatteryManager
import android.content.IntentFilter
import androidx.core.view.WindowCompat
import android.os.Bundle
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream

// সম্পূর্ণ ব্যাকগ্রাউন্ডে স্পষ্ট ও উজ্জ্বল রেড এবং রয়্যাল ব্লুর চমৎকার মিশ্রণ
private val VIBRANT_RED = Color(0xFFFF0D55)
private val ROYAL_BLUE = Color(0xFF0051FF)
private val NEON_CYAN = Color(0xFF00E5FF)
private val DARK_BG_BLUE = Color(0xFF060B24)
private val DARK_BG_RED = Color(0xFF2A0314)

private val FULL_BG_GRADIENT = Brush.verticalGradient(
    listOf(DARK_BG_RED, DARK_BG_BLUE, Color(0xFF020410))
)

class MainActivity : ComponentActivity() {
    override fun onResume() {
        super.onResume()
        PriyaState.resume.value++
        try { Keep.ensureAccessibility(this) } catch (_: Exception) {}
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { 
            MaterialTheme(colorScheme = darkColorScheme(primary = VIBRANT_RED, secondary = ROYAL_BLUE)) { 
                App() 
            } 
        }
    }
}

private fun hasP(c: android.content.Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

private fun startPriya(c: android.content.Context) {
    if (Store.apiKey(c).isBlank()) { Toast.makeText(c, "প্রথমে Menu > Gemini API Key দিন", Toast.LENGTH_LONG).show(); return }
    ContextCompat.startForegroundService(c, Intent(c, PriyaService::class.java))
}
private fun stopPriya(c: android.content.Context) { c.startService(Intent(c, PriyaService::class.java).setAction("STOP")) }


/** রেজিস্ট্রি ছাড়াই res/raw ভিডিও লুপে চালায়; স্ক্রিন ভরে (center-crop), শব্দ বন্ধ, অডিও ফোকাস নেয় না */
@Composable
private fun LoopVideo(modifier: Modifier = Modifier) {
    androidx.compose.ui.viewinterop.AndroidView(modifier = modifier, factory = { c ->
        val box = android.widget.FrameLayout(c)
        box.setBackgroundColor(android.graphics.Color.BLACK)
        try {
            val vv = android.widget.VideoView(c)
            vv.setAudioFocusRequest(android.media.AudioManager.AUDIOFOCUS_NONE)
            box.addView(vv, android.widget.FrameLayout.LayoutParams(-1, -1, android.view.Gravity.CENTER))
            vv.setVideoURI(Uri.parse("android.resource://" + c.packageName + "/" + R.raw.rea_loop))
            vv.setOnPreparedListener { mp ->
                try {
                    mp.isLooping = true
                    mp.setVolume(0f, 0f)
                    val vw = mp.videoWidth.toFloat(); val vh = mp.videoHeight.toFloat()
                    fun fit() {
                        val bw = box.width.toFloat(); val bh = box.height.toFloat()
                        if (bw <= 0f || bh <= 0f || vw <= 0f || vh <= 0f) return
                        val sc = maxOf(bw / vw, bh / vh)
                        vv.layoutParams = android.widget.FrameLayout.LayoutParams((vw * sc).toInt(), (vh * sc).toInt(), android.view.Gravity.CENTER)
                    }
                    fit(); box.post { fit() }
                    vv.start()
                } catch (_: Exception) {}
            }
            vv.setOnErrorListener { _, _, _ -> true }
        } catch (_: Exception) {}
        box
    })
}

/** ভিডিওর হলোগ্রাম "AI" রিংয়ের ওপর ভয়েস-রিঅ্যাক্টিভ স্পন্দন */
@Composable
private fun VoiceHud(speaking: Boolean, listening: Boolean, wave: Float, spin: Float, modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val a = if (speaking) 1f else if (listening) 0.35f else 0f
        if (a <= 0f) return@Canvas
        val c = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height * 0.70f)
        val base = size.height * 0.31f / 2f
        for (i in 0..2) {
            val ph = (wave + i / 3f) % 1f
            drawCircle(NEON_CYAN.copy(alpha = (1f - ph) * 0.6f * a), radius = base * (1f + ph * 0.5f), center = c,
                style = androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
        }
        val d = base * 2f
        drawArc(VIBRANT_RED.copy(alpha = 0.9f * a), spin, 70f, false,
            androidx.compose.ui.geometry.Offset(c.x - base, c.y - base), androidx.compose.ui.geometry.Size(d, d),
            style = androidx.compose.ui.graphics.drawscope.Stroke(4.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
        drawArc(NEON_CYAN.copy(alpha = 0.9f * a), -spin * 1.4f, 50f, false,
            androidx.compose.ui.geometry.Offset(c.x - base * 0.88f, c.y - base * 0.88f), androidx.compose.ui.geometry.Size(d * 0.88f, d * 0.88f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var page by remember { mutableStateOf("home") }
    var menu by remember { mutableStateOf(false) }
    var chat by remember { mutableStateOf(false) }
    var always by remember { mutableStateOf(Store.always(ctx)) }
    val running by PriyaState.running.collectAsState()
    val status by PriyaState.status.collectAsState()

    val isSpeaking = status.contains("বলছে") || status.contains("Priya bol")
    val infiniteTransition = rememberInfiniteTransition(label = "3D Rotate")
    val rotationY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotationY"
    )

    val hudWave by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "hudWave"
    )
    val hudSpin by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart), label = "hudSpin"
    )

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) startPriya(ctx) }
    var camOn by remember { mutableStateOf(false) }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) camOn = true }
    LaunchedEffect(running) { if (!running) camOn = false }
    LaunchedEffect(camOn) { PriyaState.cameraOn = camOn }
    var arWa by remember { mutableStateOf(Store.autoReplyWhatsApp(ctx)) }
    var arImo by remember { mutableStateOf(Store.autoReplyImo(ctx)) }
    var arMsg by remember { mutableStateOf(Store.autoReplyMessenger(ctx)) }

    fun toggleMic() {
        if (running) stopPriya(ctx)
        else if (!hasP(ctx, Manifest.permission.RECORD_AUDIO)) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        else startPriya(ctx)
    }

    LaunchedEffect(Unit) {
        if (always && !running && hasP(ctx, Manifest.permission.RECORD_AUDIO) && Store.apiKey(ctx).isNotBlank()) startPriya(ctx)
    }
    BackHandler(page != "home") { page = "home" }

    when (page) {
        "perm" -> PermPage { page = "home" }
        "key" -> KeyPage { page = "home" }
        "mem" -> MemPage { page = "home" }
        "settings" -> SettingsPage { page = "home" }
        else -> HomeScreen(
            running = running, isSpeaking = isSpeaking, status = status, camOn = camOn,
            onMenu = { menu = true },
            onMic = { toggleMic() },
            onCam = {
                if (!running) Toast.makeText(ctx, "আগে মাইক অন করে রিয়াকে চালু করুন", Toast.LENGTH_SHORT).show()
                else if (camOn) camOn = false
                else if (hasP(ctx, Manifest.permission.CAMERA)) camOn = true
                else camPerm.launch(Manifest.permission.CAMERA)
            },
            onChat = { chat = true },
            onSettings = { page = "settings" }
        )
    }

    if (menu) AlertDialog(
        onDismissRequest = { menu = false },
        confirmButton = { TextButton({ menu = false }) { Text("Close", color = NEON_CYAN) } },
        title = { Text("Menu", color = Color.White) },
        containerColor = Color(0xFF140722),
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton({ menu = false; page = "perm" }) { Text("Permissions", color = Color.White) }
                TextButton({ menu = false; page = "key" }) { Text("Gemini API Key", color = Color.White) }
                TextButton({ menu = false; page = "mem" }) { Text("Memory (30 MB)", color = Color.White) }
                TextButton({ menu = false; page = "settings" }) { Text("Settings", color = Color.White) }
                Text("Screen Watch: সবসময় চালু (বাধ্যতামূলক)", color = NEON_CYAN)
                TextButton({ menu = false; try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }) { Text("Notification access দিন (অটো রিপ্লাইয়ের জন্য)", color = Color.White) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("WhatsApp অটো রিপ্লাই", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(arWa, { arWa = it; Store.setAutoReplyWhatsApp(ctx, it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("imo অটো রিপ্লাই", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(arImo, { arImo = it; Store.setAutoReplyImo(ctx, it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Messenger অটো রিপ্লাই", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(arMsg, { arMsg = it; Store.setAutoReplyMessenger(ctx, it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Always Listening (App খুললেই)", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(always, { always = it; Store.setAlways(ctx, it) })
                }
            }
        }
    )

    if (chat) ChatDialog { chat = false }
}

@Composable
fun ChatDialog(close: () -> Unit) {
    val log by PriyaState.log.collectAsState()
    var t by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, confirmButton = { TextButton(close) { Text("Close", color = NEON_CYAN) } }, 
        title = { Text("Chat", color = Color.White) },
        containerColor = Color(0xFF140722),
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 300.dp)) { 
                    items(log) { 
                        Text(it, Modifier.padding(vertical = 3.dp), fontSize = 14.sp, color = Color.White) 
                    } 
                }
                OutlinedTextField(
                    value = t, 
                    onValueChange = { t = it }, 
                    modifier = Modifier.fillMaxWidth(), 
                    placeholder = { Text("রিয়াকে লিখুন…") },
                    trailingIcon = { 
                        TextButton({ if (t.isNotBlank()) { PriyaState.live?.sendText(t); t = "" } }) { 
                            Text("Send", color = VIBRANT_RED) 
                        } 
                    }
                )
                if (!PriyaState.running.value) Text("মাইক অন করে আগে রিয়াকে শুরু করুন", color = Color.Gray, fontSize = 12.sp)
            }
        }
    )
}

private class Perm(val name: String, val why: String, val ok: Boolean, val go: () -> Unit,
                   val hint: String? = null, val hintLabel: String = "", val hintGo: (() -> Unit)? = null)

private class Sp(val id: String, val ok: Boolean, val go: () -> Unit)

@Composable
fun PermPage(back: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val resume by PriyaState.resume.collectAsState()
    LaunchedEffect(Unit) { while (true) { delay(700); tick++ } }
    val stamp = tick + resume // এই স্টেট পড়ার ফলে পেজ নিজে থেকে রিফ্রেশ হয়
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val multi = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    fun rt(p: String) = { launcher.launch(p) }
    fun open(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { Keep.openAppInfo(ctx) } }
    val pkg = Uri.parse("package:${ctx.packageName}")
    val prefs = ctx.getSharedPreferences("priya", android.content.Context.MODE_PRIVATE)
    val accOk = Keep.accessibilityOn(ctx)
    val overlayOk = Settings.canDrawOverlays(ctx)
    val batOk = (ctx.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    val dndOk = (ctx.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).isNotificationPolicyAccessGranted
    val oemOk = prefs.getBoolean("oemDone", false)
    val accGo = { if (!Keep.ensureAccessibility(ctx)) Keep.openAccessibility(ctx) }
    val batGo = { Keep.openBattery(ctx) }
    val oemGo = { prefs.edit().putBoolean("oemDone", true).apply(); Keep.openOemAutostart(ctx); Unit }

    val runtime = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    val missingRt = runtime.filter { !hasP(ctx, it) }
    val specials = listOf(
        Sp("acc", accOk, accGo),
        Sp("overlay", overlayOk) { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) },
        Sp("bat", batOk, batGo),
        Sp("dnd", dndOk) { open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) },
        Sp("oem", oemOk, oemGo)
    )

    // ⚡ একসাথে সব চালু: প্রথমে সব রানটাইম পারমিশন, তারপর একটার পর একটা বিশেষ সেটিংস নিজে খুলবে
    var wizard by remember { mutableStateOf(false) }
    var lastActed by remember { mutableIntStateOf(-1) }
    val asked = remember { mutableSetOf<String>() }
    var askedRt by remember { mutableStateOf(false) }
    LaunchedEffect(stamp, wizard) {
        if (!wizard || resume == lastActed) return@LaunchedEffect
        if (!askedRt && missingRt.isNotEmpty()) {
            askedRt = true; lastActed = resume
            multi.launch(missingRt.toTypedArray()); return@LaunchedEffect
        }
        val next = specials.firstOrNull { !it.ok && it.id !in asked }
        if (next != null) {
            asked.add(next.id)
            if (next.id == "acc" && Keep.ensureAccessibility(ctx)) { lastActed = -1; return@LaunchedEffect }
            lastActed = resume
            next.go(); return@LaunchedEffect
        }
        wizard = false
        val allOk = missingRt.isEmpty() && specials.all { it.ok || it.id == "oem" }
        Toast.makeText(ctx, if (allOk) "সব অনুমতি চালু ✓" else "কিছু অনুমতি এখনও বাকি, নিচে দেখো", Toast.LENGTH_LONG).show()
    }

    val list = listOf(
        Perm("Microphone", "ভয়েসে কথা বলার জন্য", hasP(ctx, Manifest.permission.RECORD_AUDIO), rt(Manifest.permission.RECORD_AUDIO)),
        Perm("Bluetooth", "ব্লুটুথ হেডসেট/TWS কানেক্টের জন্য",
            Build.VERSION.SDK_INT < 31 || hasP(ctx, Manifest.permission.BLUETOOTH_CONNECT),
            if (Build.VERSION.SDK_INT >= 31) rt(Manifest.permission.BLUETOOTH_CONNECT) else ({})),
        Perm("Camera", "ছবি দেখে কথা বলার জন্য", hasP(ctx, Manifest.permission.CAMERA), rt(Manifest.permission.CAMERA)),
        Perm("Accessibility", "ফোন নিয়ন্ত্রণ ও স্ক্রিন সার্বক্ষণিক পর্যবেক্ষণের জন্য", accOk, accGo,
            hint = "সুইচ ধূসর হলে বা চালু না হলে: App info → ⋮ (উপরে ডানে) → Restricted settings অনুমতি দাও, তারপর আবার Allow চাপো।",
            hintLabel = "App info খোলো", hintGo = { Keep.openAppInfo(ctx) }),
        Perm("Display over apps", "অন্যান্য অ্যাপের ওপর কাজ করতে", overlayOk, specials[1].go),
        Perm("Battery optimization OFF", "ব্যাকগ্রাউন্ডে সচল থাকতে", batOk, batGo),
        Perm("Autostart / Background (OEM)", "Xiaomi, Oppo, Realme, Vivo ইত্যাদিতে সিস্টেম যেন Rea বন্ধ না করে", oemOk, oemGo,
            hint = "খোলা পেজে Rea-র Autostart / Allow background চালু করো। Recents-এ Rea কার্ড লক (🔒) করে রাখো।"),
        Perm("Do Not Disturb access", "ফোন সাইলেন্ট করার জন্য", dndOk, specials[3].go),
        Perm("Contacts", "নাম দিয়ে সরাসরি কল দিতে", hasP(ctx, Manifest.permission.READ_CONTACTS), rt(Manifest.permission.READ_CONTACTS)),
        Perm("Phone calls", "কল লাগানোর জন্য", hasP(ctx, Manifest.permission.CALL_PHONE), rt(Manifest.permission.CALL_PHONE))
    )
    Column(Modifier.fillMaxSize().background(FULL_BG_GRADIENT).statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", color = Color.White, fontSize = 20.sp) }
            Text("Permissions", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold)
        }
        Button(
            onClick = { asked.clear(); askedRt = false; lastActed = -1; wizard = true },
            Modifier.fillMaxWidth().padding(bottom = 10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = VIBRANT_RED)
        ) { Text(if (wizard) "চালু করা হচ্ছে… প্রতিটি পেজে Allow দাও" else "⚡ সব একসাথে চালু করো") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { p ->
                Column(Modifier.fillMaxWidth().background(Color(0xFF1B0D2E), RoundedCornerShape(14.dp)).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(p.why, color = Color.Gray, fontSize = 12.sp)
                        }
                        if (p.ok) Text("✓ ON", color = NEON_CYAN) else Button(p.go, colors = ButtonDefaults.buttonColors(containerColor = VIBRANT_RED)) { Text("Allow") }
                    }
                    if (p.hint != null && !p.ok) {
                        Text(p.hint, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                        if (p.hintGo != null) TextButton(p.hintGo) { Text(p.hintLabel, color = NEON_CYAN) }
                    }
                }
            }
            item {
                Text(
                    "স্থায়ী সমাধান (ঐচ্ছিক): একবার এই কমান্ড দিলে Rea নিজেই Accessibility বন্ধ হলে আবার চালু করে নেবে:\n" +
                        "adb shell pm grant ${ctx.packageName} android.permission.WRITE_SECURE_SETTINGS",
                    color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
fun KeyPage(back: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Store.apiKey(ctx)) }
    var model by remember { mutableStateOf(Store.model(ctx)) }
    var voice by remember { mutableStateOf(Store.voice(ctx)) }
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(FULL_BG_GRADIENT).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { 
            TextButton(back) { Text("←", color = Color.White, fontSize = 20.sp) }
            Text("Gemini API Key", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold) 
        }
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API Key") }, singleLine = true,
            visualTransformation = if (show) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation())
        TextButton({ show = !show }) { Text(if (show) "Hide" else "Show", color = NEON_CYAN) }
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Live model") }, singleLine = true)
        OutlinedTextField(voice, { voice = it }, Modifier.fillMaxWidth(), label = { Text("Voice (Leda)") }, singleLine = true)
        Text("Key aistudio.google.com থেকে সংগ্রহ করুন।", color = Color.LightGray, fontSize = 12.sp)
        Button(
            onClick = { 
                Store.setApiKey(ctx, key)
                Store.setModel(ctx, model)
                Store.setVoice(ctx, voice)
                Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
                back() 
            }, 
            Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = VIBRANT_RED)
        ) { 
            Text("Save") 
        }
    }
}

@Composable
fun MemPage(back: () -> Unit) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val used = remember(refresh) { Store.size(ctx) }
    val text = remember(refresh) { Store.recent(ctx, 4000) }
    Column(Modifier.fillMaxSize().background(FULL_BG_GRADIENT).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { 
            TextButton(back) { Text("←", color = Color.White, fontSize = 20.sp) }
            Text("Memory", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold) 
        }
        Text("%.2f MB / 30 MB ব্যবহৃত হয়েছে".format(used / 1048576.0), color = Color.White)
        LinearProgressIndicator(progress = { (used.toFloat() / Store.CAP).coerceIn(0f, 1f) }, Modifier.fillMaxWidth(), color = VIBRANT_RED)
        Text("স্মৃতিসমূহ:", color = NEON_CYAN)
        Text(text.ifBlank { "এখনো কোনো মেমোরি সেভ হয়নি" }, Modifier.weight(1f).verticalScroll(rememberScrollState()), color = Color.White, fontSize = 13.sp)
        OutlinedButton({ Store.clear(ctx); refresh++ }, Modifier.fillMaxWidth()) { Text("স্মৃতি মুছে ফেলুন", color = VIBRANT_RED) }
    }
}

// ---- হোম স্ক্রিন: ডিজাইন ছবি পুরো স্ক্রিনে (ContentScale.Crop), বাটনগুলো ছবির সাথে মিলিয়ে ট্যাপ এলাকা ----

private fun launchPkg(c: android.content.Context, pkg: String) {
    val i = c.packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    else Toast.makeText(c, "এই অ্যাপটি ফোনে পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
}

@Composable
private fun Hot(x: Dp, y: Dp, w: Dp, h: Dp, onClick: () -> Unit) {
    Box(Modifier.offset(x = x, y = y).size(w, h).clickable(onClick = onClick))
}

@Composable
fun HomeScreen(
    running: Boolean,
    isSpeaking: Boolean,
    status: String,
    camOn: Boolean,
    onMenu: () -> Unit,
    onMic: () -> Unit,
    onCam: () -> Unit,
    onChat: () -> Unit,
    onSettings: () -> Unit
) {
    val ctx = LocalContext.current
    BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF03060F))) {
        // ছবি পুরো স্ক্রিন ঢাকবে (উপর-নিচে কোনো ফাঁকা জায়গা থাকবে না), প্রস্থ বেশি হলে দুই পাশ সামান্য কাটা যাবে
        val iw = 941f
        val ih = 2091f // প্যাডেড ছবি (941x2091, ফোনের 0.45 অনুপাতে)
        val sw = maxWidth.value
        val sh = maxHeight.value
        val scale = maxOf(sw / iw, sh / ih)
        val dw = iw * scale
        val dh = ih * scale
        val ox = (sw - dw) / 2f
        val oy = (sh - dh) / 2f
        fun px(fx: Float): Dp = (ox + fx * dw).dp
        fun py(fy: Float): Dp = (oy + fy * dh).dp
        fun pw(f: Float): Dp = (f * dw).dp
        fun ph(f: Float): Dp = (f * dh).dp
        @Composable
        // ডিজাইন ছবির (941x1672) ভগ্নাংশকে প্যাডেড ছবির ভগ্নাংশে বদলানো (উপরে 209px প্যাড)
        fun fy(f: Float): Float = (f * 1672f + 209f) / 2091f
        fun fh(f: Float): Float = f * 1672f / 2091f
        @Composable
        fun hot(cx: Float, cy: Float, w: Float, h: Float, onClick: () -> Unit) {
            val cyP = fy(cy)
            val hP = fh(h)
            Hot(px(cx - w / 2f), py(cyP - hP / 2f), pw(w), ph(hP), onClick)
        }

        Image(
            painter = painterResource(R.drawable.home_bg),
            contentDescription = "Rea home",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Text(
            text = status,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = py(fy(0.135f)))
                .background(Color(0xCC050B1E), RoundedCornerShape(20.dp))
                .border(1.dp, NEON_CYAN.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                .padding(horizontal = 14.dp, vertical = 4.dp)
        )

        if (camOn) {
            LiveCamera(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(y = py(fy(0.20f)))
                    .padding(end = 14.dp)
                    .size(width = 120.dp, height = 160.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(2.dp, NEON_CYAN, RoundedCornerShape(16.dp))
            )
        }

        hot(0.104f, 0.057f, 0.14f, 0.075f, onMenu)
        hot(0.256f, 0.811f, 0.16f, 0.06f, onCam)
        hot(0.5f, 0.804f, 0.22f, 0.12f, onMic)
        hot(0.741f, 0.811f, 0.16f, 0.06f, onChat)

        hot(0.123f, 0.904f, 0.14f, 0.08f) { launchPkg(ctx, "com.whatsapp") }
        hot(0.275f, 0.904f, 0.14f, 0.08f) { launchPkg(ctx, "com.imo.android.imoim") }
        hot(0.427f, 0.904f, 0.14f, 0.08f) { launchPkg(ctx, "com.facebook.orca") }
        hot(0.581f, 0.904f, 0.14f, 0.08f) { launchPkg(ctx, "com.google.android.youtube") }
        hot(0.735f, 0.904f, 0.14f, 0.08f) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        hot(0.887f, 0.904f, 0.14f, 0.08f, onSettings)
    }
}

// ---- Settings পেজ: বক্স আকারে, ছোট আইকন সহ, অবস্থা (ON/OFF) দেখায় ----

private fun openIntent(c: android.content.Context, i: Intent) {
    try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { Toast.makeText(c, "খোলা যায়নি", Toast.LENGTH_SHORT).show() }
}

private fun setTorch(c: android.content.Context, on: Boolean): String {
    return try {
        val cam = c.getSystemService(android.content.Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        val id = cam.cameraIdList.firstOrNull { cid ->
            cam.getCameraCharacteristics(cid).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "এই ফোনে ফ্ল্যাশ নেই"
        cam.setTorchMode(id, on)
        if (on) "ফ্ল্যাশলাইট চালু" else "ফ্ল্যাশলাইট বন্ধ"
    } catch (e: Exception) {
        "ফ্ল্যাশ নিয়ন্ত্রণ করা গেল না"
    }
}

private fun setRinger(c: android.content.Context, mode: String): String {
    val am = c.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager
    return try {
        am.ringerMode = when (mode) {
            "silent" -> AudioManager.RINGER_MODE_SILENT
            "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        "সাউন্ড মোড বদলানো হয়েছে"
    } catch (e: SecurityException) {
        openIntent(c, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        "সাইলেন্ট করতে Do Not Disturb অনুমতি দিন"
    }
}

private fun wifiState(c: android.content.Context): Boolean = try {
    @Suppress("DEPRECATION")
    (c.applicationContext.getSystemService(android.content.Context.WIFI_SERVICE) as android.net.wifi.WifiManager).isWifiEnabled
} catch (e: Exception) { false }

private fun btState(c: android.content.Context): Boolean = try {
    (c.getSystemService(android.content.Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager)?.adapter?.isEnabled == true
} catch (e: Exception) { false }

private fun ringerLabel(c: android.content.Context): String {
    val am = c.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager
    return when (am.ringerMode) {
        AudioManager.RINGER_MODE_SILENT -> "SILENT"
        AudioManager.RINGER_MODE_VIBRATE -> "VIBRATE"
        else -> "NORMAL"
    }
}

private fun batteryPct(c: android.content.Context): Int {
    val bat = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    return if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
}

@Composable
private fun TileIcon(kind: String, color: Color) {
    Canvas(Modifier.size(26.dp)) {
        val w = size.width
        val h = size.height
        val st = androidx.compose.ui.graphics.drawscope.Stroke(width = w * 0.12f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        when (kind) {
            "wifi" -> {
                for (k in 1..3) {
                    val r = w * (0.2f * k)
                    drawArc(color = color, startAngle = 225f, sweepAngle = 90f, useCenter = false,
                        topLeft = androidx.compose.ui.geometry.Offset(w / 2f - r, h * 0.9f - r),
                        size = androidx.compose.ui.geometry.Size(r * 2f, r * 2f), style = st)
                }
                drawCircle(color = color, radius = w * 0.08f, center = androidx.compose.ui.geometry.Offset(w / 2f, h * 0.9f))
            }
            "bt" -> {
                val p = androidx.compose.ui.graphics.Path().apply {
                    moveTo(w * 0.3f, h * 0.3f); lineTo(w * 0.7f, h * 0.7f); lineTo(w * 0.5f, h * 0.95f)
                    lineTo(w * 0.5f, h * 0.05f); lineTo(w * 0.7f, h * 0.3f); lineTo(w * 0.3f, h * 0.7f)
                }
                drawPath(p, color = color, style = st)
            }
            "torch" -> {
                val p = androidx.compose.ui.graphics.Path().apply {
                    moveTo(w * 0.3f, h * 0.08f); lineTo(w * 0.7f, h * 0.08f); lineTo(w * 0.6f, h * 0.45f)
                    lineTo(w * 0.6f, h * 0.92f); lineTo(w * 0.4f, h * 0.92f); lineTo(w * 0.4f, h * 0.45f); close()
                }
                drawPath(p, color = color, style = st)
            }
            "sound" -> {
                val p = androidx.compose.ui.graphics.Path().apply {
                    moveTo(w * 0.08f, h * 0.36f); lineTo(w * 0.3f, h * 0.36f); lineTo(w * 0.55f, h * 0.12f)
                    lineTo(w * 0.55f, h * 0.88f); lineTo(w * 0.3f, h * 0.64f); lineTo(w * 0.08f, h * 0.64f); close()
                }
                drawPath(p, color = color, style = st)
                drawArc(color = color, startAngle = -50f, sweepAngle = 100f, useCenter = false,
                    topLeft = androidx.compose.ui.geometry.Offset(w * 0.55f, h * 0.28f),
                    size = androidx.compose.ui.geometry.Size(w * 0.4f, h * 0.44f), style = st)
            }
            else -> {
                drawRoundRect(color = color, topLeft = androidx.compose.ui.geometry.Offset(w * 0.05f, h * 0.25f),
                    size = androidx.compose.ui.geometry.Size(w * 0.8f, h * 0.5f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f), style = st)
                drawRect(color = color, topLeft = androidx.compose.ui.geometry.Offset(w * 0.88f, h * 0.4f),
                    size = androidx.compose.ui.geometry.Size(w * 0.07f, h * 0.2f))
            }
        }
    }
}

@Composable
private fun StateTile(
    modifier: Modifier,
    title: String,
    kind: String,
    on: Boolean,
    value: String,
    onClick: () -> Unit
) {
    val accent = if (on) NEON_CYAN else Color(0xFF7C86A2)
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .shadow(if (on) 14.dp else 2.dp, shape, spotColor = accent)
            .background(Brush.verticalGradient(listOf(Color(0xFF17213F), Color(0xFF0B1028))), shape)
            .border(
                1.dp,
                if (on) Brush.linearGradient(listOf(NEON_CYAN, ROYAL_BLUE)) else Brush.linearGradient(listOf(Color(0xFF3A4260), Color(0xFF3A4260))),
                shape
            )
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(46.dp)
                    .background(
                        Brush.radialGradient(listOf(accent.copy(alpha = 0.45f), Color.Transparent)),
                        CircleShape
                    )
                    .border(1.5.dp, accent, CircleShape),
                contentAlignment = Alignment.Center
            ) { TileIcon(kind, accent) }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .background(
                        if (on) Brush.horizontalGradient(listOf(NEON_CYAN, ROYAL_BLUE)) else Brush.horizontalGradient(listOf(Color(0xFF2A2F3E), Color(0xFF2A2F3E))),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    value,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp,
                    color = if (on) Color.White else Color(0xFFB8BFD6)
                )
            }
        }
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 0.3.sp)
    }
}

@Composable
fun SettingsPage(back: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var torchOn by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { delay(1500); tick++ } }
    val wifiOn = remember(tick) { wifiState(ctx) }
    val btOn = remember(tick) { btState(ctx) }
    val mode = remember(tick) { ringerLabel(ctx) }
    val pct = remember(tick) { batteryPct(ctx) }

    Column(
        Modifier.fillMaxSize().background(FULL_BG_GRADIENT).statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", color = Color.White, fontSize = 20.sp) }
            Text("Settings", fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold)
        }
        if (note.isNotEmpty()) Text(note, color = NEON_CYAN, fontSize = 12.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StateTile(Modifier.weight(1f), "Wi-Fi", "wifi", wifiOn, if (wifiOn) "ON" else "OFF") {
                openIntent(ctx, Intent(Settings.Panel.ACTION_WIFI))
                note = "খোলা প্যানেলে Wi-Fi চালু/বন্ধ করুন"
            }
            StateTile(Modifier.weight(1f), "Bluetooth", "bt", btOn, if (btOn) "ON" else "OFF") {
                openIntent(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                note = "Bluetooth সেটিংসে চালু/বন্ধ করুন"
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StateTile(Modifier.weight(1f), "Flashlight", "torch", torchOn, if (torchOn) "ON" else "OFF") {
                torchOn = !torchOn
                note = setTorch(ctx, torchOn)
            }
            StateTile(Modifier.weight(1f), "Sound mode", "sound", mode == "NORMAL", mode) {
                val next = when (mode) { "NORMAL" -> "vibrate"; "VIBRATE" -> "silent"; else -> "normal" }
                note = setRinger(ctx, next)
            }
        }
        StateTile(Modifier.fillMaxWidth(), "Battery", "battery", true, if (pct >= 0) "$pct%" else "N/A") {}
    }
}
