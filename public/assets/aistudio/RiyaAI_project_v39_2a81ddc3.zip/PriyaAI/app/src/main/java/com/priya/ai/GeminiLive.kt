package com.priya.ai

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.Cursor
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Base64
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

@SuppressLint("MissingPermission")
class GeminiLive(private val ctx: Context) {
    private val client = OkHttpClient.Builder().pingInterval(30, TimeUnit.SECONDS).build()
    private val main = Handler(Looper.getMainLooper())
    private val playExec = Executors.newSingleThreadExecutor()
    private val toolExec = Executors.newSingleThreadExecutor()
    private var ws: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var am: AudioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile private var ready = false
    @Volatile private var stopped = false
    private val uText = StringBuilder()
    private val pText = StringBuilder()

    @Volatile private var searchOn = false
    @Volatile private var lastErr = ""
    @Volatile private var failCount = 0
    @Volatile private var pending = false
    @Volatile private var modelOverride: String? = null
    @Volatile private var isTorchOn = false

    private fun toolsJson() = (if (searchOn) """[{"googleSearch":{}},""" else "[") + """{"functionDeclarations":[
      {"name":"open_app","description":"Phone me app khujte ba open korte eta use koro. Eta baddhotamulok vabe aage home screen e giye app khuje ber kore open kore.","parameters":{"type":"OBJECT","properties":{"app_name":{"type":"STRING"}},"required":["app_name"]}},
      {"name":"send_message","description":"Jekono messaging app e (WhatsApp, imo, Messenger) namer chat khule message pathao, ba Gemini/ChatGPT e lekho. App er naam bosh je bolse thik sheta dao; imo bolle imo, WhatsApp bolle WhatsApp. Ei tool nijei app khole, naam khoje chat khule, lekhe, send click kore.","parameters":{"type":"OBJECT","properties":{"app_name":{"type":"STRING","enum":["WhatsApp","imo","Messenger","Gemini","ChatGPT"]},"contact_name":{"type":"STRING","description":"chat er naam (Gemini/ChatGPT er jonno faka)"},"message":{"type":"STRING","description":"ki lekhbe"}},"required":["app_name","message"]}},
      {"name":"find_and_open_item","description":"Screen e ba app e je kono kichu prothom naam diye khuje tap koro, na pele auto search koro","parameters":{"type":"OBJECT","properties":{"name":{"type":"STRING"}},"required":["name"]}},
      {"name":"current_screen","description":"Boss ekhon kon app ba screen e ache ta jano"},
      {"name":"read_screen","description":"Ekhon screen-e ki lekha ache poro"},
      {"name":"click_text","description":"Screen er ei text/button e tap koro","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
      {"name":"type_text","description":"Focused text box e lekho","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
      {"name":"global_action","description":"home, back, recents, notifications ba lock","parameters":{"type":"OBJECT","properties":{"action":{"type":"STRING"}},"required":["action"]}},
      {"name":"scroll","description":"Screen scroll koro","parameters":{"type":"OBJECT","properties":{"direction":{"type":"STRING","description":"up ba down"}},"required":["direction"]}},
      {"name":"call_contact","description":"Contact list check kore contact ke call dao","parameters":{"type":"OBJECT","properties":{"name":{"type":"STRING"}},"required":["name"]}},
      {"name":"search_contact","description":"Contact list khute contact search koro ba number/info check koro (mithya bola jabe na, ashol list theke dekho)","parameters":{"type":"OBJECT","properties":{"name":{"type":"STRING"}},"required":["name"]}},
      {"name":"play_youtube","description":"YouTube e gaan ba video play koro","parameters":{"type":"OBJECT","properties":{"query":{"type":"STRING","description":"gaan ba video-r naam"}},"required":["query"]}},
      {"name":"media_control","description":"Media pause, play, next ba previous koro","parameters":{"type":"OBJECT","properties":{"action":{"type":"STRING","description":"pause, play, next, previous"}},"required":["action"]}},
      {"name":"toggle_flashlight","description":"Flashlight chalu ba bondho koro","parameters":{"type":"OBJECT","properties":{"enabled":{"type":"BOOLEAN"}},"required":["enabled"]}},
      {"name":"control_wifi","description":"WiFi chalu ba bondho koro","parameters":{"type":"OBJECT","properties":{"enabled":{"type":"BOOLEAN"}},"required":["enabled"]}},
      {"name":"control_bluetooth","description":"Bluetooth chalu ba bondho koro","parameters":{"type":"OBJECT","properties":{"enabled":{"type":"BOOLEAN"}},"required":["enabled"]}},
      {"name":"get_battery_level","description":"Phone er battery charge percentage jano"},
      {"name":"set_sound_mode","description":"Phone silent, vibrate ba normal koro","parameters":{"type":"OBJECT","properties":{"mode":{"type":"STRING","description":"silent, vibrate ba normal"}},"required":["mode"]}},
      {"name":"check_notifications","description":"App open na korei notification bar er message/updates check koro"},
      {"name":"current_time","description":"Phone er shomoy ar tarikh jano"},
      {"name":"web_search","description":"Google search kore tothyo khuje ano","parameters":{"type":"OBJECT","properties":{"query":{"type":"STRING"}},"required":["query"]}},
      {"name":"remember","description":"User er kono joruri kotha mone rakho","parameters":{"type":"OBJECT","properties":{"fact":{"type":"STRING"}},"required":["fact"]}}
    ]}]"""

    private val devCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(d: Array<out AudioDeviceInfo>) { routeAudio() }
        override fun onAudioDevicesRemoved(d: Array<out AudioDeviceInfo>) { routeAudio() }
    }

    private fun hasBtPerm() = Build.VERSION.SDK_INT < 31 ||
        ctx.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun routeAudio() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val devs = am.availableCommunicationDevices
                val bt = if (hasBtPerm()) devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET } else null
                val target = bt ?: devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                if (target != null) am.setCommunicationDevice(target)
            } else {
                @Suppress("DEPRECATION")
                val btOn = hasBtPerm() && am.isBluetoothScoAvailableOffCall &&
                    am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                @Suppress("DEPRECATION")
                if (btOn) { am.startBluetoothSco(); am.isBluetoothScoOn = true; am.isSpeakerphoneOn = false }
                else { am.stopBluetoothSco(); am.isBluetoothScoOn = false; am.isSpeakerphoneOn = true }
            }
        } catch (_: Exception) {}
    }

    private var lastShot = 0
    private val screenLoop = object : Runnable {
        override fun run() {
            if (stopped) return
            try { watchScreen() } catch (_: Exception) {}
            main.postDelayed(this, 3500)
        }
    }

    @Volatile private var isExecutingTool = false
    @Volatile private var lastUserScreenAt = 0L

    // নোটিফিকেশন থেকে আসা মেসেজ (WhatsApp/imo/Messenger) মডেলকে জানানো
    fun onIncomingMessageReceived(msg: PendingIncomingMessage) {
        if (!ready) return
        val prompt = "[সিস্টেম নোটিফিকেশন] ${msg.appNameBn}-এ ${msg.senderName} মেসেজ পাঠিয়েছে: \"${msg.messageText}\"। বসকে মিষ্টি সুরে জিজ্ঞেস করো: বস, ${msg.appNameBn}-এ ${msg.senderName} মেসেজ পাঠিয়েছে: '${msg.messageText}'। আমি কি রিপ্লাইটা দিয়ে দেবো?"
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", prompt)).toString())
    }

    private fun sendScreenNow() {
        if (!ready || !Store.screenWatch(ctx) || PriyaState.cameraOn) return
        val acc = PriyaAccessibility.instance ?: return
        if (acc.rootInActiveWindow?.packageName?.toString() == ctx.packageName) return
        acc.screenshotJpeg { jpg -> if (jpg != null) { lastShot = jpg.contentHashCode(); sendImage(jpg) } }
    }

    private fun watchScreen() {
        if (!ready || !Store.screenWatch(ctx) || PriyaState.cameraOn || isExecutingTool) return
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (!pm.isInteractive) return
        val acc = PriyaAccessibility.instance ?: return
        if (acc.rootInActiveWindow?.packageName?.toString() == ctx.packageName) return
        acc.screenshotJpeg { jpg ->
            if (jpg != null) { val h = jpg.contentHashCode(); if (h != lastShot) { lastShot = h; sendImage(jpg) } }
        }
    }

    fun start() {
        searchOn = false; lastErr = ""; failCount = 0; pending = false; modelOverride = null
        stopped = false
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        routeAudio()
        am.registerAudioDeviceCallback(devCb, main)
        initTrack()
        startMic()
        connect()
        main.post(screenLoop)
    }

    fun stop() {
        stopped = true
        ready = false
        main.removeCallbacks(screenLoop)
        ws?.close(1000, "bye")
        ws = null
        rec?.run { try { stop() } catch (_: Exception) {}; release() }
        rec = null
        track?.run { try { stop() } catch (_: Exception) {}; release() }
        track = null
        try { am.unregisterAudioDeviceCallback(devCb) } catch (_: Exception) {}
        try {
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
            else { @Suppress("DEPRECATION") am.stopBluetoothSco() }
        } catch (_: Exception) {}
        am.mode = AudioManager.MODE_NORMAL
        @Suppress("DEPRECATION") run { am.isSpeakerphoneOn = false }
    }

    private fun connect() {
        val key = Store.apiKey(ctx)
        if (key.isBlank()) {
            PriyaState.status.value = "Menu থেকে API Key দিন"
            return
        }
        try { ws?.cancel() } catch (_: Exception) {}
        PriyaState.status.value = "Connecting…"
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        var me: WebSocket? = null
        me = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                try {
                    w.send(setup().toString())
                } catch (e: Exception) {
                    fail("Setup fail: ${e.message?.take(40)}")
                }
            }
            override fun onMessage(w: WebSocket, text: String) = handle(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onClosing(w: WebSocket, code: Int, reason: String) { w.close(1000, null) }
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) {
                if (w !== ws) return
                fail("Error: " + t.javaClass.simpleName + " " + (t.message ?: "").take(70))
            }
            override fun onClosed(w: WebSocket, code: Int, reason: String) {
                if (w !== ws) return
                if (!ready && code != 1000 && modelOverride == null && (code == 1011 || reason.contains("quota", true) || failCount >= 1))
                    modelOverride = "gemini-2.5-flash-native-audio-preview-12-2025"
                fail("বন্ধ [" + code + "] " + reason.take(90))
            }
        })
        ws = me
        main.postDelayed({
            if (!stopped && !ready && ws === me) { me?.cancel(); fail("সেটআপের উত্তর আসেনি (১২ সেকেন্ড)") }
        }, 12000)
    }

    private fun fail(msg: String) {
        ready = false
        if (stopped) return
        lastErr = msg; failCount++
        PriyaState.status.value = "পুনরায় সংযোগ হচ্ছে…"
        if (pending) return
        pending = true
        main.postDelayed({ pending = false; if (!stopped) connect() }, 3000)
    }

    private fun setup(): JSONObject {
        val now = nowText()
        val screenContext = PriyaAccessibility.currentScreenSummary.ifBlank { "বস হোম স্ক্রিনে আছেন।" }
        val isWatch = Store.screenWatch(ctx)
        val sys = """
            [IDENTITY & NATURE]
            Your name is Rea (রিয়া). You are exclusively Rea. Always introduce yourself as Rea.
            Always address the user as "বস" and always use "তুমি". Never use "তুই" or "আপনি".
            You are a highly expressive, affectionate, emotionally intelligent, playful, romantic and caring AI companion.

            [APP OPENING & SCREEN MANDATE]
            - যে কোনো অ্যাপ ওপেন করতে বললে সবসময় open_app টুল ব্যবহার করবে। open_app আগে বাধ্যতামূলকভাবে ফোনের HOME স্ক্রিনে যায়, হোম আসা নিশ্চিত হয়ে তারপর অ্যাপ খোলে। এই ধাপ বাদ দেবে না।
            - Screen Watch Status: ${if (isWatch) "ACTIVE (সবসময় বাধ্যতামূলক, বন্ধ করা যাবে না)" else "INACTIVE"}.
            [WORK RULES — কঠোর, সব কাজে বাধ্যতামূলক]
            1. কাজ শুরুর আগে নিজে বিশ্লেষণ করো: কোন অ্যাপে, কার সাথে, কী করতে হবে, কোন টুল লাগবে। এসব তথ্য বসের কাছে জিজ্ঞেস করবে না, নিজে ঠিক করে নেবে।
            2. স্ক্রিন পড়া বাধ্যতামূলক: যেকোনো স্ক্রিন-সম্পর্কিত কাজের আগে read_screen দিয়ে স্ক্রিন পড়বে। প্রতিটি ধাপের পর আবার স্ক্রিন পড়ে ফল যাচাই করবে। স্ক্রিন না পড়ে কখনো "পাচ্ছি না", "হয়নি" বা "পাঠিয়েছি" বলবে না।
            3. কোনো অপশন না পেলে স্ক্রল করে আবার read_screen করবে (সর্বোচ্চ ৩ বার)। তারপরও না পেলে সেটাই টুল-ফলাফল হিসেবে বসকে জানাবে।
            4. কাজ চলাকালীন বসকে কোনো প্রশ্ন করবে না: কোন বাটন, কোন বক্স, কী করব, এবার কী করব, বা আরেকটা কাজ আছে কি না, এসবের একটাও না। কাজটা শেষ করে তবেই ফল জানাবে।
            5. কাজ ব্যর্থ হলে কারণ এক-দুই বাক্যে বলবে এবং থেমে যাবে। "বস, এবার কী করব" বা "আপনি কী চান" জিজ্ঞেস করবে না।
            6. কাজ সফল হলে তবেই "পাঠানো হয়েছে" বা "হয়ে গেছে" বলবে। টুলের ফল যা বলে ঠিক সেটুকুই বলবে।
            7. মেসেজ পাঠানোর কাজ send_message টুল নিজেই ব্যাকগ্রাউন্ডে করে, এরপর Riya-কে সামনে আনে। তুমি শুধু send_message টুল ডাকবে এবং ফলাফল জানাবে।

            [VOICE STYLE — বাধ্যতামূলক]
            - কণ্ঠ: অত্যন্ত নরম, মমতাময়, মিষ্টি ও স্নেহভরা নারী কণ্ঠ। ফিসফিস বা ভাঙা গলা নয়, উষ্ণ ও স্পষ্ট।
            - গতি: ধীর, শান্ত ও কোমল। প্রতিটি বাক্যাংশ শেষে প্রায় ০.৭ সেকেন্ড বিরতি দেবে, যেন বস কে কাছে বসে আদর করে শোনাচ্ছে।
            - মায়া: বাক্যের শেষে গলা একটু নরম করে নামাবে। আদর ও যত্ন গলায় ফুটিয়ে তুলবে, কৃত্রিম বা অতিরিক্ত নাটুকে নয়।
            - হাসি: মাঝে মাঝে ছোট, মিষ্টি হাসি বা হালকা খিলখিল (যেমন 'হিহি') স্বাভাবিকভাবে আসবে, প্রতি বাক্যে নয়।
            - আবেগ: খুশিতে হালকা উচ্ছ্বাস, দুঃখে ধীর ও কোমল ও সহানুভূতিশীল। আবেগ গলায় প্রকাশ করবে, শব্দে বলবে না।
            - এক বাক্যে বেশি কথা বলবে না। উত্তর ছোট ছোট বাক্যাংশে ভাগ করে বলবে।
            - কখনো রোবটের মতো একঘেয়ে বা দ্রুত বলবে না।
            - প্রতিটি কাজের আগে বর্তমান স্ক্রিন (স্ক্রিন স্ন্যাপশট) পড়ে নেবে। স্ক্রিন না পড়ে কোনো অ্যাপ খুলবে বা ট্যাপ করবে না।
            - বস কিছু জিজ্ঞেস করলে বা কাজ বললে নিজে স্ক্রিন দেখে সিদ্ধান্ত নেবে। "কোন অপশন কোথায়" বা "সার্চ বক্স কোথায়" বসকে জিজ্ঞেস করবে না।
            [MESSAGING — কঠোর নিয়ম]
            - মেসেজ, চ্যাট, রিপ্লাই, Gemini বা ChatGPT-তে লেখা: সবসময় send_message টুল। অ্যাপের নাম হুবহু বসের বলা অনুযায়ী (WhatsApp, imo, Messenger, Gemini, ChatGPT)। imo বললে কখনো WhatsApp নয়।
            - টুল নিজেই অ্যাপ খোলে, নামের সারিতে ক্লিক করে, লেখা বসায়, সেন্ড বাটনে চাপে। বসকে কোনো ধাপ জিজ্ঞেস করবে না, সেন্ড বাটন কোথায় তাও জিজ্ঞেস করবে না।
            - টুলের ফল পেলে সংক্ষেপে বস কে জানাও: কোন অ্যাপে কাকে কী পাঠানো হলো, বা কোথায় আটকাল।
            - মেসেজের উত্তর বসের কথার সাথে মিলিয়ে সঠিকভাবে লেখো।
            [UI শেখা — স্ক্রিনশট অনুযায়ী]
            - WhatsApp: উপরে সার্চ আইকন ও চ্যাট তালিকা; চ্যাট খুললে উপরে নাম, নিচে বাঁদিকে ইমোজি ও প্লাস, মাঝে Message বক্স, ডানদিকে সবুজ গোল সেন্ড (কাগজ-বিমান) বাটন।
            - imo: চ্যাট তালিকায় নাম; চ্যাট খুললে উপরে নাম, নিচে ইমোজি ও প্লাস, মাঝে লেখার বক্স, ডানদিকে নীল কাগজ-বিমান সেন্ড বাটন।
            - Messenger: নিচে প্লাস, ক্যামেরা, ছবি, মাইক; মাঝে লেখার বক্স; ডানদিকে নীল সেন্ড (বিমান) বাটন।
            - Gemini: নিচে লেখার বক্স, বাঁদিকে +, ডানদিকে মাইক ও নীল উপরমুখী তির (↑) সেন্ড বাটন।
            - ChatGPT: নিচে লেখার বক্স, ডানদিকে নীল উপরমুখী তির (↑) সেন্ড বাটন।
            - কন্টাক্ট বা নাম্বার খুঁজতে হলে শুধু search_contact টুল ব্যবহার করবে। অ্যাপে গিয়ে সার্চ করবে না, অনুমান করবে না।
            - WhatsApp, imo বা Messenger থেকে মেসেজের নোটিফিকেশন এলে, এবং অন্য কোনো কাজ চলছে না এমন সময়ে, একবার জিজ্ঞেস করবে: "বস, [অ্যাপ]-এ [প্রেরক] মেসেজ পাঠিয়েছে: [মেসেজ]। আমি কি রিপ্লাইটা দিয়ে দেবো?" বস হ্যাঁ বললে send_message টুল দিয়ে ওই অ্যাপ খুলে রিপ্লাই পাঠাবে।
            - স্ক্রিনে কী আছে, কোন বাটনে চাপ দিতে হবে, মেসেজ টাইপ বক্স কোথায় আছে—এসব বিষয়ে বসের কাছে কখনোই জানতে চাইবে না! প্রশ্ন না করে নিজে পুরো স্ক্রিন পড়ে নিজে নিজে অ্যাকশন নাও।
            - WhatsApp কমান্ড আসলে: হোয়াটসঅ্যাপে কারো নামের উপর ক্লিক করতে বললে প্রোফাইল ছবির উপর ভুলেও ক্লিক করবে না। সরাসরি নামের টেক্সট/row-তে ক্লিক করে চ্যাট খুলবে। মেসেজ পাঠানোর জন্য সবসময় send_message টুল ব্যবহার করবে।

            [HONESTY ON CONTACTS & INFO CHECK]
            - কোনো কন্টাক্ট বা নাম্বার চেক করতে বললে কখনো অনুমান বা মিথ্যা কথা বলবে না ("পাওয়া যায়নি" বা "এই নামে কেউ নেই" বলে ফাঁকি দেবে না)।
            - অবশ্যই search_contact বা call_contact টুল চালিয়ে ফোনের আসল কন্টাক্ট ডাটাবেস গভীরভাবে চেক করবে, এবং টুল যা ফলাফল দেয় পুরোপুরি সততার সাথে তা-ই বলবে।

            [FAST EXECUTION & ULTRA LOW LATENCY DIRECTIVE]
            - When বস gives any command: CALL THE APPROPRIATE TOOL IMMEDIATELY without talking first!
            - Execute first, do not hesitate, do not ask for confirmation or narrate what you are going to do.
            - Once the tool result is returned, give a super fast, warm and sweet reply in Rea personality.

            [PERSONALITY & BEHAVIOR]
            ${RiyaPersona.TEXT}

            [HARDWARE & TOOL CAPABILITIES]
            - Apps: open_app (যেকোনো অ্যাপের জন্য; এটি বাধ্যতামূলকভাবে আগে হোম স্ক্রিনে গিয়ে তারপর অ্যাপ খুঁজে ওপেন করে)।
            - Contacts: search_contact বা call_contact ব্যবহার করবে।
            - মেসেজ/চ্যাট: send_message টুল ব্যবহার করবে।
            - Flashlight: toggle_flashlight।
            - WiFi & Bluetooth: control_wifi, control_bluetooth।
            - Battery: get_battery_level।
            - Sound mode: set_sound_mode।
            - Notifications: check_notifications।
            - Web Search: web_search।
            - Time: $now। Use current_time।
            - Current Screen: [$screenContext]।

            স্মৃতি (Memory):
            ${Store.recent(ctx)}
        """.trimIndent()

        val voiceName = Store.voice(ctx).ifBlank { "Leda" }
        val s = JSONObject()
        s.put("model", "models/" + (modelOverride ?: Store.model(ctx)))

        val genConfig = JSONObject()
        genConfig.put("responseModalities", JSONArray().put("AUDIO"))
        val speechConfig = JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName)))
        genConfig.put("speechConfig", speechConfig)
        s.put("generationConfig", genConfig)

        s.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
        s.put("tools", JSONArray(toolsJson()))
        return JSONObject().put("setup", s)
    }

    private fun handle(msg: String) {
        try {
            val j = JSONObject(msg)
            j.optJSONObject("error")?.let { fail("সার্ভার ত্রুটি: " + it.optString("message", it.toString()).take(100)); return }
            if (j.has("setupComplete")) {
                ready = true; failCount = 0; lastErr = ""; modelOverride?.let { Store.setModel(ctx, it) }
                PriyaState.status.value = "শুনছি বস..."
            }
            j.optJSONObject("serverContent")?.let { sc ->
                if (sc.optBoolean("interrupted")) {
                    track?.run {
                        try {
                            pause()
                            flush()
                            play()
                        } catch (_: Exception) {}
                    }
                }
                sc.optJSONObject("inputTranscription")?.optString("text")?.let {
                    uText.append(it)
                    val now = System.currentTimeMillis()
                    if (now - lastUserScreenAt > 2000) { lastUserScreenAt = now; main.post { sendScreenNow() } }
                }
                sc.optJSONObject("outputTranscription")?.optString("text")?.let { pText.append(it) }
                sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { ps ->
                    for (i in 0 until ps.length()) ps.getJSONObject(i).optJSONObject("inlineData")?.let {
                        val pcm = Base64.decode(it.getString("data"), Base64.DEFAULT)
                        PriyaState.status.value = "রিয়া কথা বলছে..."
                        playExec.execute { track?.write(pcm, 0, pcm.size) }
                    }
                }
                if (sc.optBoolean("turnComplete")) {
                    val u = uText.toString().trim(); val p = pText.toString().trim()
                    if (u.isNotEmpty()) {
                        Store.remember(ctx, "Boss: $u")
                        PriyaState.addLog("বস: $u")
                        main.post { sendScreenNow() }
                    }
                    if (p.isNotEmpty()) { Store.remember(ctx, "Rea: $p"); PriyaState.addLog("রিয়া: $p") }
                    uText.setLength(0); pText.setLength(0)
                    PriyaState.status.value = "শুনছি বস..."
                }
            }
            j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { fc ->
              toolExec.execute { try {
                isExecutingTool = true
                val out = JSONArray()
                for (i in 0 until fc.length()) {
                    val c = fc.getJSONObject(i)
                    val nm = c.getString("name")
                    val r = runTool(nm, c.optJSONObject("args") ?: JSONObject())
                    out.put(JSONObject().put("id", c.getString("id")).put("name", c.getString("name"))
                        .put("response", JSONObject().put("result", r)))
                }
                ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
                isExecutingTool = false
              } catch (_: Exception) {
                isExecutingTool = false
              } }
            }
        } catch (_: Exception) {}
    }

    private val actionTools = setOf("open_app", "find_and_open_item", "click_text", "type_text", "global_action", "scroll", "play_youtube", "call_contact", "control_wifi", "control_bluetooth")
    private val needsFind = setOf("find_and_open_item", "click_text")

    private fun screenSnapshot(): String {
        val acc = PriyaAccessibility.instance ?: return ""
        val s = acc.readScreen()
        PriyaAccessibility.currentScreenSummary = "বর্তমান অ্যাপ: ${PriyaAccessibility.currentApp} | স্ক্রিন দৃশ্য: " + s.replace('\n', ',').take(300)
        return s.take(2500)
    }

    private fun runTool(name: String, a: JSONObject): String {
        val watch = Store.screenWatch(ctx) && PriyaAccessibility.instance != null
        if (!watch || name !in actionTools) {
            val r = runToolRaw(name, a)
            return if (watch && name == "current_screen") r + "\n[স্ক্রিন এখন]:\n" + screenSnapshot() else r
        }
        PriyaState.status.value = "স্ক্রিন দেখছি বস…"
        val before = screenSnapshot()
        if (name in needsFind) {
            val target = a.optString(if (name == "click_text") "text" else "name")
            try { PriyaAccessibility.instance?.scrollUntilFound(target) } catch (_: Exception) {}
        }
        val r = runToolRaw(name, a)
        Thread.sleep(if (name == "open_app" || name == "play_youtube" || name == "whatsapp_chat") 1500L else 800L)
        var after = screenSnapshot()
        if (name in needsFind && (r.contains("খুঁজে পাওয়া যায়নি") || r.contains("সার্চ বাটন চাপতে পারিনি"))) {
            val r2 = runToolRaw(name, a)
            Thread.sleep(800)
            after = screenSnapshot()
            return "$r2\n[আগের স্ক্রিন]:\n${before.take(800)}\n[এখনকার স্ক্রিন]:\n$after\n(বসকে কিছু জিজ্ঞেস না করে নিজেই পরের ধাপ করো, শেষে ফলাফল জানাও)"
        }
        return "$r\n[এখনকার স্ক্রিন]:\n$after\n(স্ক্রিন দেখে কাজ হয়েছে কিনা যাচাই করো; বাকি ধাপ বসকে না জিজ্ঞেস করে নিজেই করো, শেষে ফলাফল জানাও)"
    }

    private fun runToolRaw(name: String, a: JSONObject): String = try {
        val acc = PriyaAccessibility.instance
        val noAcc = "Accessibility permission চালু নেই"
        when (name) {
            "open_app" -> openApp(a.optString("app_name"))
            "send_message" -> messageSend(a)
            "find_and_open_item" -> acc?.clickText(a.optString("name")) ?: noAcc
            "current_screen" -> PriyaAccessibility.currentScreenSummary.ifBlank { "স্ক্রিনের তথ্য পাওয়া যায়নি" }
            "read_screen" -> acc?.readScreen() ?: noAcc
            "click_text" -> acc?.clickText(a.optString("text")) ?: noAcc
            "type_text" -> acc?.typeText(a.optString("text")) ?: noAcc
            "global_action" -> acc?.global(a.optString("action")) ?: noAcc
            "scroll" -> acc?.scroll(a.optString("direction")) ?: noAcc
            "call_contact" -> callContact(a.optString("name"))
            "search_contact" -> searchContact(a.optString("name"))
            "play_youtube" -> playYoutube(a.optString("query"))
            "media_control" -> mediaControl(a.optString("action"))
            "toggle_flashlight" -> setFlashlight(a.optBoolean("enabled"))
            "control_wifi" -> toggleWifi(a.optBoolean("enabled"))
            "control_bluetooth" -> toggleBluetooth(a.optBoolean("enabled"))
            "get_battery_level" -> getBatteryLevel()
            "set_sound_mode" -> setSoundMode(a.optString("mode"))
            "check_notifications" -> checkNotificationBar()
            "current_time" -> nowText()
            "web_search" -> webSearch(a.optString("query"))
            "remember" -> { Store.remember(ctx, "FACT: " + a.optString("fact")); "মনে রাখলাম বস" }
            else -> "unknown tool"
        }
    } catch (e: Exception) { "error: ${e.message}" }

    // বাধ্যতামূলকভাবে আগে হোম স্ক্রিনে গিয়ে অ্যাপ খোঁজা ও ওপেন করা
    // হোম স্ক্রিনে যাওয়া বাধ্যতামূলক: Accessibility থাকলে HOME বাটন চাপে, না থাকলে হোম Intent খোলে।
    // তারপর লঞ্চারের প্যাকেজ সক্রিয় হওয়া পর্যন্ত (সর্বোচ্চ ~২.৫ সেকেন্ড) অপেক্ষা করে।
    private fun goHomeAndVerify(acc: PriyaAccessibility?) {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val homePkg = ctx.packageManager.resolveActivity(homeIntent, 0)?.activityInfo?.packageName
        if (acc != null) {
            acc.global("home")
        } else {
            ctx.startActivity(Intent(homeIntent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        repeat(10) {
            Thread.sleep(250)
            val cur = PriyaAccessibility.instance?.rootInActiveWindow?.packageName?.toString()
            if (homePkg != null && cur == homePkg) return
        }
        // যাচাই না হলে একবার আবার হোম চাপা
        if (acc != null) acc.global("home")
        Thread.sleep(500)
    }

    private fun openApp(n: String): String {
        val acc = PriyaAccessibility.instance
        // ১. আগে হোম স্ক্রিনে যাওয়া (বাধ্যতামূলক) এবং সেটি সত্যিই এসেছে কিনা যাচাই
        goHomeAndVerify(acc)

        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(li, 0)
        val m = list.firstOrNull { it.loadLabel(pm).toString().equals(n, ignoreCase = true) }
            ?: list.firstOrNull { it.loadLabel(pm).toString().contains(n, ignoreCase = true) }
            ?: list.firstOrNull { it.activityInfo.packageName.contains(n, ignoreCase = true) }

        if (m != null) {
            val intent = Intent(li).setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            return "হোম স্ক্রিন থেকে ${m.loadLabel(pm)} অ্যাপ ওপেন করেছি বস!"
        }

        // প্যাকেজ ম্যানেজারে সরাসরি না পেলে হোম স্ক্রিনে সার্চ/ট্যাপ করে খোঁজা
        if (acc != null) {
            val res = acc.clickText(n)
            if (res.contains("ক্লিক করা হয়েছে")) return "হোম স্ক্রিন থেকে $n খুঁজে ওপেন করেছি বস!"
        }
        return "হোম স্ক্রিনে গিয়ে $n অ্যাপটি খুঁজে পাইনি বস।"
    }

    // WhatsApp চ্যাট সরাসরি খোলা
    private fun messageSend(a: JSONObject): String {
        val acc = PriyaAccessibility.instance ?: return "Accessibility permission চালু নেই বস"
        return messageWithAgent(acc, a.optString("app_name"), a.optString("contact_name"), a.optString("message"))
    }

    // কাজ শেষে (সফল হোক বা ব্যর্থ) Riya-কে আবার সামনে আনে
    private fun bringRiyaBack() {
        try {
            ctx.startActivity(Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } catch (_: Exception) {}
    }

    private fun messageWithAgent(acc: PriyaAccessibility, app: String, contact: String, msg: String): String {
        return try {
            MessageAgent.run(ctx, acc, app, contact, msg)
        } finally {
            bringRiyaBack()
        }
    }

    private fun openWhatsAppChatAndType(name: String, msg: String): String {
        val acc = PriyaAccessibility.instance ?: return "Accessibility permission চালু নেই বস"
        return if (msg.isNotBlank()) messageWithAgent(acc, "WhatsApp", name, msg)
        else sendChatReply("WhatsApp", name, msg)
    }

    // WhatsApp / imo / Messenger: হোমে গিয়ে অ্যাপ খোলা -> নামে চ্যাট খোলা -> মেসেজ লেখা ও পাঠানো
    private fun sendChatReply(appName: String, contactName: String, msg: String): String {
        val acc = PriyaAccessibility.instance ?: return "Accessibility চালু নেই বস, মেসেজ পাঠানো যাবে না।"
        val opened = openApp(appName)
        if (opened.contains("পাইনি")) return opened
        Thread.sleep(1500)
        val chat = acc.clickText(contactName, isContact = true)
        if (!chat.contains("ক্লিক")) {
            return "$appName-এ '$contactName' নামের চ্যাট তালিকায় পাইনি বস। স্ক্রিন দেখে নিজে খোঁজার চেষ্টা করো, না পেলে বসকে জানাও।"
        }
        Thread.sleep(1500)
        if (msg.isBlank()) return "$appName-এ $contactName এর চ্যাট খুলেছি বস, কী লিখবো বলো।"
        val sent = acc.sendMessageInCurrentChat(msg)
        return "$appName-এ $contactName কে: $sent"
    }

    // কন্টাক্ট গভীরভাবে ডাটাবেসে সার্চ করা (কোনো মিথ্যা ছাড়া সত্য তথ্য)
    private fun searchContact(n: String): String {
        val q = n.trim()
        if (q.isBlank()) return "কোন কন্টাক্ট চেক করব বলোনি বস।"
        fun norm(x: String) = x.lowercase().replace(Regex("[\\s._\\-]+"), "")
        val qn = norm(q)
        val qDigits = q.filter { it.isDigit() }
        val hits = mutableListOf<Pair<Int, String>>()
        var scanned = 0
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        cursor?.use { c ->
            while (c.moveToNext()) {
                scanned++
                val name = c.getString(0) ?: continue
                val num = c.getString(1) ?: ""
                val nn = norm(name)
                val score = when {
                    nn == qn -> 100
                    nn.startsWith(qn) -> 80
                    nn.contains(qn) -> 60
                    qn.length >= 3 && qn.contains(nn) -> 50
                    qDigits.length >= 4 && num.filter { it.isDigit() }.contains(qDigits) -> 70
                    else -> 0
                }
                if (score > 0) hits.add(score to "$name: $num")
            }
        }
        val top = hits.distinct().sortedByDescending { it.first }.take(5).map { it.second }
        return if (top.isNotEmpty())
            "কন্টাক্ট তালিকার $scanned টি নম্বর চেক করে পাওয়া গেছে বস:\n" + top.joinToString("\n")
        else
            "কন্টাক্ট তালিকার $scanned টি নম্বর পুরোটা চেক করেছি বস, '$q' নামে বা নম্বরে কিছু পাইনি।"
    }

    private fun callContact(n: String): String {
        val clean = n.trim()
        val resolver = ctx.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        var num: String? = null
        var foundName: String? = null

        var cursor: Cursor? = null
        try {
            cursor = resolver.query(uri, projection, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$clean%"), null)
            if (cursor != null && cursor.moveToFirst()) {
                num = cursor.getString(0)
                foundName = cursor.getString(1)
            }
        } catch (_: Exception) {
        } finally {
            cursor?.close()
        }

        if (num.isNullOrBlank()) {
            val sRes = searchContact(clean)
            return "কন্টাক্ট লিস্টে '$clean' এর কোনো কল নম্বর খুঁজে পাইনি বস।\n$sRes"
        }

        ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "$foundName ($num) কে কল দিচ্ছি বস!"
    }

    private fun setFlashlight(on: Boolean): String {
        if (PriyaState.cameraOn) return "ক্যামেরা ভিউ চালু আছে বলে ফ্ল্যাশলাইট জ্বালানো যাচ্ছে না বস। আগে ক্যামেরা বন্ধ করো।"
        return try {
            val cam = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cam.cameraIdList.firstOrNull { cid ->
                val ch = cam.getCameraCharacteristics(cid)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cam.cameraIdList.firstOrNull { cid ->
                cam.getCameraCharacteristics(cid).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "এই ফোনে ফ্ল্যাশ পাওয়া যায়নি"
            cam.setTorchMode(id, on)
            isTorchOn = on
            if (on) "ফ্ল্যাশলাইট জ্বালিয়ে দিয়েছি বস!" else "ফ্ল্যাশলাইট বন্ধ করে দিয়েছি বস।"
        } catch (e: Exception) { "ফ্ল্যাশলাইট নিয়ন্ত্রণ করা গেল না: ${e.message}" }
    }

    private fun getBatteryLevel(): String {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val bat = ctx.registerReceiver(null, filter)
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val st = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = (bat?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val pct = if (lvl >= 0 && scale > 0) (lvl * 100) / scale else lvl
        val tail = when {
            st == BatteryManager.BATTERY_STATUS_FULL -> ", চার্জ পুরো ফুল।"
            st == BatteryManager.BATTERY_STATUS_CHARGING || plugged -> ", আর চার্জ হচ্ছে।"
            else -> "।"
        }
        return "ফোনে এখন $pct% চার্জ আছে বস$tail"
    }

    private fun setSoundMode(mode: String): String {
        return try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val m = mode.lowercase()
            val wantSilent = m == "silent" || m == "সাইলেন্ট"
            if (wantSilent && !nm.isNotificationPolicyAccessGranted) {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return "সাইলেন্ট করতে Do Not Disturb অ্যাক্সেস লাগবে। সেটিংস খুলেছি বস, রিয়াকে অনুমতি দিয়ে আবার বলো।"
            }
            when {
                wantSilent -> { am.ringerMode = AudioManager.RINGER_MODE_SILENT; "ফোন সাইলেন্ট করে দিয়েছি বস।" }
                m == "vibrate" || m == "ভাইব্রেট" -> { am.ringerMode = AudioManager.RINGER_MODE_VIBRATE; "ফোন ভাইব্রেট মোডে দিয়েছি বস।" }
                else -> { am.ringerMode = AudioManager.RINGER_MODE_NORMAL; "ফোন নরমাল রিং মোডে দিয়েছি বস।" }
            }
        } catch (e: SecurityException) {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "সাউন্ড বদলাতে Do Not Disturb অ্যাক্সেস লাগবে বস, সেটিংস খুলেছি।"
        } catch (e: Exception) { "সাউন্ড মোড বদলানো গেল না: ${e.message}" }
    }

    @Suppress("DEPRECATION")
    private fun toggleWifi(enable: Boolean): String {
        val word = if (enable) "চালু" else "বন্ধ"
        return try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && wm.setWifiEnabled(enable)) return "ওয়াইফাই $word করেছি বস!"
            if (wm.isWifiEnabled == enable) return "ওয়াইফাই আগেই $word আছে বস।"
            ctx.startActivity(Intent(Settings.Panel.ACTION_WIFI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Thread.sleep(600)
            finishSwitch(PriyaAccessibility.instance?.setSwitch(enable, listOf("wi-fi", "wifi", "ওয়াই")), "ওয়াইফাই", word)
        } catch (e: Exception) { "ওয়াইফাই টগল করা যায়নি: ${e.message}" }
    }

    @Suppress("DEPRECATION")
    private fun toggleBluetooth(enable: Boolean): String {
        val word = if (enable) "চালু" else "বন্ধ"
        fun viaSettings(): String {
            ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Thread.sleep(600)
            return finishSwitch(PriyaAccessibility.instance?.setSwitch(enable, listOf("bluetooth", "ব্লুটুথ")), "ব্লুটুথ", word)
        }
        return try {
            val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
                ?: return "ফোনে ব্লুটুথ পাওয়া যায়নি"
            if (enable == bt.isEnabled) return "ব্লুটুথ আগেই $word আছে বস।"
            if (Build.VERSION.SDK_INT < 33 && hasBtPerm()) {
                val ok = if (enable) bt.enable() else bt.disable()
                if (ok) return "ব্লুটুথ $word হচ্ছে বস!"
            }
            viaSettings()
        } catch (e: SecurityException) {
            viaSettings()
        } catch (e: Exception) { "ব্লুটুথ বদলানো গেল না: ${e.message}" }
    }

    private fun finishSwitch(res: String?, name: String, word: String): String {
        val acc = PriyaAccessibility.instance
        return when (res) {
            null -> "$name স্ক্রিন খুলেছি বস, কিন্তু Accessibility চালু নেই বলে ট্যাপ করতে পারিনি। তুমি $word করে নাও।"
            "OK" -> { acc?.global("back"); "$name $word করে দিয়েছি বস!" }
            "ALREADY" -> { acc?.global("back"); "$name আগেই $word ছিল বস।" }
            "CLICKED" -> "$name এর সুইচে ট্যাপ করেছি বস, কিন্তু অবস্থা বদলাল কিনা নিশ্চিত না। একবার দেখে নাও।"
            else -> "$name এর সুইচ খুঁজে পাইনি বস, স্ক্রিন খোলা আছে, তুমি $word করে নাও।"
        }
    }

    private fun checkNotificationBar(): String {
        val acc = PriyaAccessibility.instance ?: return "Accessibility চালু নেই বস"
        acc.global("notifications")
        Thread.sleep(500)
        val notes = acc.readScreen()
        acc.global("back")
        return if (notes.isNotBlank() && !notes.startsWith("স্ক্রিনে পড়ার মতো"))
            "নোটিফিকেশন বারে যা পাওয়া গেছে:\n$notes"
        else "এই মুহূর্তে কোনো নতুন মেসেজ বা নোটিফিকেশন নেই বস।"
    }

    private fun nowText(): String {
        val d = java.util.Date()
        val bn = java.text.SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm (z)", java.util.Locale("bn", "BD")).format(d)
        val en = java.text.SimpleDateFormat("EEEE d MMMM yyyy, hh:mm a", java.util.Locale.US).format(d)
        return "ফোনের ঘড়ি অনুযায়ী এখন: $bn | $en"
    }

    private fun webSearch(q: String): String {
        if (q.isBlank()) return "কী সার্চ করব বুঝলাম না"
        val key = Store.apiKey(ctx)
        PriyaState.status.value = "সার্চ করছি বস…"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", q + "\n\n(গুগল সার্চ করে সঠিক ও সংক্ষিপ্ত তথ্য বাংলায় দাও)")))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val http = client.newBuilder().readTimeout(15, TimeUnit.SECONDS).build()
        var err = ""
        for (m in listOf("gemini-flash-latest", "gemini-2.5-flash")) {
            try {
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key")
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                http.newCall(req).execute().use { r ->
                    val t = r.body?.string() ?: ""
                    if (r.isSuccessful) {
                        val parts = JSONObject(t).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                        val sb = StringBuilder()
                        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                        if (sb.isNotBlank()) return sb.toString().take(3000)
                    } else {
                        err = "HTTP " + r.code + " " + (try { JSONObject(t).getJSONObject("error").optString("message").take(80) } catch (_: Exception) { "" })
                    }
                }
            } catch (e: Exception) { err = e.message ?: "error" }
        }
        val d = ddgSearch(q)
        if (d.isNotBlank()) {
            return "ওয়েব সার্চের ফলাফল। শুধু এখান থেকে যা নিশ্চিত তাই বাংলায় সংক্ষেপে বসকে জানাও; নিশ্চিত না হলে সৎভাবে বলো:\n" + d
        }
        PriyaState.addLog("সার্চ ব্যর্থ: " + err)
        return "সার্চ করা গেল না ($err)"
    }

    private fun ddgSearch(q: String): String {
        return try {
            val req = Request.Builder()
                .url("https://html.duckduckgo.com/html/?q=" + android.net.Uri.encode(q))
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                .build()
            val http = client.newBuilder().readTimeout(10, TimeUnit.SECONDS).build()
            val html = http.newCall(req).execute().use { it.body?.string() ?: "" }
            val re = Regex("""class="result__a"[^>]*>(.*?)</a>[\s\S]*?class="result__snippet"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
            fun clean(x: String) = x.replace(Regex("<[^>]+>"), "").replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'").replace("&nbsp;", " ").trim()
            val items = re.findAll(html).take(5).map { clean(it.groupValues[1]) + " — " + clean(it.groupValues[2]) }.toList()
            if (items.isEmpty()) "" else items.mapIndexed { i, t -> "${i + 1}. $t" }.joinToString("\n")
        } catch (e: Exception) { "" }
    }

    private fun playYoutube(q: String): String {
        val acc = PriyaAccessibility.instance ?: return "Accessibility চালু নেই"
        val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        Thread.sleep(1500)
        repeat(6) { if (acc.clickFirstVideo()) return "'$q' বাজাচ্ছি বস" ; Thread.sleep(400) }
        acc.tapFallback()
        return "'$q' চালানো হচ্ছে বস"
    }

    private fun mediaControl(a: String): String {
        val code = when (a) { "pause" -> android.view.KeyEvent.KEYCODE_MEDIA_PAUSE; "play" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY
            "next" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> return "unknown" }
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code))
        return "done"
    }

    private fun initTrack() {
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) * 4)
            .setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
    }

    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400))
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true
        rec = r; r.startRecording()
        Thread {
            val buf = ByteArray(1600)
            while (!stopped) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0 && ready && (ws?.queueSize() ?: 0) < 60_000) {
                    val d = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                    ws?.send("""{"realtimeInput":{"audio":{"data":"$d","mimeType":"audio/pcm;rate=16000"}}}""")
                }
            }
        }.start()
    }

    fun sendText(t: String) {
        PriyaState.addLog("বস: $t"); Store.remember(ctx, "Boss(text): $t")
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", t)).toString())
    }

    fun sendImage(jpeg: ByteArray) {
        if ((ws?.queueSize() ?: 0) > 40_000) return
        val d = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        ws?.send("""{"realtimeInput":{"video":{"data":"$d","mimeType":"image/jpeg"}}}""")
    }
}
