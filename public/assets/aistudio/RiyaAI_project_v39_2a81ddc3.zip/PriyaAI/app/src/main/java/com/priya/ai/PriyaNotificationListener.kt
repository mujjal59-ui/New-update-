package com.priya.ai

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// WhatsApp, imo, Messenger-এর নতুন মেসেজ ধরে Rea-কে জানায়। অটো-রিপ্লাই সুইচ বন্ধ থাকলে কিছুই করে না।
data class PendingIncomingMessage(
    val appType: String,
    val appNameBn: String,
    val senderName: String,
    val messageText: String,
    val packageName: String
)

class PriyaNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        val appType: String
        val appNameBn: String
        when (pkg) {
            "com.whatsapp", "com.whatsapp.w4b" -> { appType = "whatsapp"; appNameBn = "WhatsApp" }
            "com.imo.android.imoim", "com.imo.android.imoimbeta" -> { appType = "imo"; appNameBn = "imo" }
            "com.facebook.orca", "com.facebook.mlite" -> { appType = "messenger"; appNameBn = "Messenger" }
            else -> return
        }
        val ctx = applicationContext
        val enabled = when (appType) {
            "whatsapp" -> Store.autoReplyWhatsApp(ctx)
            "imo" -> Store.autoReplyImo(ctx)
            else -> Store.autoReplyMessenger(ctx)
        }
        if (!enabled) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        var text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""
        if (text.isBlank()) text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim() ?: ""
        if (title.isBlank() || text.isBlank()) return
        // "X messages" ধরনের সামারি নোটিফিকেশন বাদ
        if (title.equals("WhatsApp", true) || title.contains("new messages", true)) return

        val msg = PendingIncomingMessage(appType, appNameBn, title, text, pkg)
        Store.remember(ctx, "[$appNameBn] $title: $text")
        PriyaState.live?.onIncomingMessageReceived(msg)
    }
}
