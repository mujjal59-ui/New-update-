#!/data/data/com.termux/files/usr/bin/bash
# Build-er age: shob thik ache kina dekhe, choto bhul nijei thik kore
cd "$(dirname "$0")"
D=app/src/main/java/com/priya/ai
ERR=0
ok(){ echo "  ✓ $1"; }; bad(){ echo "  ✗ $1"; ERR=1; }

echo "[১] কোড ফাইল পরীক্ষা"
for f in $D/*.kt; do
  if grep -q '^--- \(START\|END\) OF FILE' "$f"; then
    sed -i '/^--- \(START\|END\) OF FILE/d' "$f"; echo "  ⚠ $(basename $f): বাড়তি '--- START OF FILE' লাইন মুছে দিয়েছি"
  fi
  first=$(grep -v '^[[:space:]]*$' "$f" | head -1)
  case "$first" in package\ com.priya.ai*) ;; *) bad "$(basename $f): প্রথম লাইন 'package com.priya.ai' নয়";; esac
  o=$(tr -cd '{' < "$f" | wc -c); c=$(tr -cd '}' < "$f" | wc -c)
  [ "$o" -ne "$c" ] && bad "$(basename $f): { } মিলছে না ($o বনাম $c)"
done
[ $ERR -eq 0 ] && ok "৬টি ফাইলের শুরু ও ব্রেস ঠিক আছে"
for f in CameraLive GeminiLive MainActivity PriyaAccessibility PriyaService Store; do
  [ -f $D/$f.kt ] || bad "$f.kt নেই"
done
[ -f app/src/main/res/drawable-nodpi/my_avatar.jpg ] && ok "আপনার ছবি আছে" || bad "my_avatar.jpg নেই"

echo "[২] SDK ও টুলস"
SDK="$HOME/android-sdk"
[ -f "$SDK/platforms/android-34/android.jar" ] && ok "Android SDK 34" || bad "SDK নেই: $SDK/platforms/android-34/android.jar"
echo "sdk.dir=$SDK" > local.properties
grep -q aapt2FromMavenOverride gradle.properties || echo "android.aapt2FromMavenOverride=$PREFIX/bin/aapt2" >> gradle.properties
command -v java >/dev/null && ok "Java আছে" || bad "Java নেই (pkg install openjdk-17)"

echo "[৩] ইন্টারনেট ও জায়গা"
if command -v curl >/dev/null; then
  curl -sI --max-time 8 https://dl.google.com >/dev/null && ok "ইন্টারনেট চালু" || echo "  ⚠ ইন্টারনেট ধীর/বন্ধ: dependency নামাতে সমস্যা হতে পারে"
fi
FREE=$(df -k "$HOME" | awk 'NR==2{print int($4/1024)}')
[ "${FREE:-0}" -lt 800 ] && echo "  ⚠ ফাঁকা জায়গা কম (${FREE}MB), অন্তত 800MB রাখুন" || ok "ফাঁকা জায়গা ${FREE}MB"

if [ $ERR -ne 0 ]; then echo; echo "✗ উপরের সমস্যা ঠিক না করে বিল্ড হবে না। বিল্ড বন্ধ।"; exit 1; fi
echo "✓ সব পরীক্ষা পাস"
