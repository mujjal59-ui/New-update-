# APK বানানোর উপায়

## সবচেয়ে সহজ: GitHub দিয়ে (পিসি/SDK লাগবে না)
1. github.com এ একটি নতুন repository খুলুন, এই ফোল্ডারের সব ফাইল আপলোড করুন (.github ফোল্ডারসহ)।
2. Actions ট্যাব → "Build APK" → Run workflow।
3. ৫-১০ মিনিট পর Artifacts থেকে `RiyaAI-apk` ডাউনলোড করুন, ভেতরে app-debug.apk।

## Android Studio দিয়ে
Open → এই ফোল্ডার → Build > Build APK(s)।

## Termux: README_TERMUX.md দেখুন।

অ্যাপ খুলে Menu > Gemini API Key এ আপনার key দিন (aistudio.google.com)।
